import time

import pyautogui

import NUM_ACR

pyautogui.moveTo(1478, 64)
pyautogui.click()
time.sleep(0.5)
pyautogui.moveTo(1674, 67)
pyautogui.click()
time.sleep(2.5)
yiqi = 627, 723, 80, 35

numbers = NUM_ACR.get_Num_ACR(*yiqi)
print("numbers1="+str(numbers))

time.sleep(1)
pyautogui.moveTo(1673, 309)
pyautogui.click()
time.sleep(0.5)
pyautogui.moveTo(1673, 309)
pyautogui.click()
time.sleep(0.5)

# pyautogui.moveTo(1659, 68)
# pyautogui.click()
# time.sleep(0.5)
# pyautogui.moveTo(1659, 68)
# pyautogui.click()
# time.sleep(2.5)
yiqi2 = 1663, 51,74,31
numbers2 = NUM_ACR.get_Num_ACR(*yiqi2)
time.sleep(1)
print("numbers2="+str(numbers2))
# time.sleep(1)
# pyautogui.moveTo(1673, 309)
# pyautogui.click()
# time.sleep(0.5)
# pyautogui.moveTo(1673, 309)
# pyautogui.click()
# time.sleep(0.5)