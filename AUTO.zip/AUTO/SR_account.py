import time#pythonproject

import Get_NUM
import SR_Code
import SR_Year
import SR_YueKa
import pytesseract
import cv2
import re
import NUM_ACR
import SR_account1
import SR_account10
import SR_account11
import SR_account12
import SR_account14
import SR_account16
import SR_account17
import SR_account2
import SR_account6
import SR_account7
import SR_account8
import SRday
import SRweituo
import SRwuming
import SRqianzhen
import pyautogui
import threading
from pynput.keyboard import Controller
import subprocess


from Getposition import get_position
from SR_jinru0 import SR_JR

# pytesseract.pytesseract.tesseract_cmd = r'C:\Users\DELL\AppData\Local\Programs\Tesseract-OCR'
access_attempts=2


def hold_key(key, duration):
    keyboard = Controller()
    keyboard.press(key)
    time.sleep(duration)
    keyboard.release(key)


def get_position3(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen(
            'C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
            confidence=0.80, region=(628, 326, 700, 479))
    return up_left
def get_position4(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen(
            'C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
            confidence=0.80, region=(685, 545, 554, 182))
    return up_left
start_event = threading.Event()
def denlu():
    num = 0
    pyautogui.FAILSAFE = False  # 关闭安全检测
    print("登录程序 等待启动信号...")
    print("-------------------------------------SR_account主号-------------------------------------------------")
    start_event.wait()
    while num < 30:

        try:
            if  get_position('using') is not None:
                pyautogui.click( 958, 704)
                time.sleep(0.5)
                pyautogui.moveTo(get_position('using'))
                pyautogui.click()
                time.sleep(0.5)
                pyautogui.click(695,571)
                time.sleep(0.5)
                pyautogui.moveTo(get_position('password'))
                pyautogui.click()
                pyautogui.write('qinruili4869')
                time.sleep(0.5)
                pyautogui.moveTo(get_position('phone'))
                time.sleep(0.5)
                pyautogui.doubleClick()
                pyautogui.write('15023134279')
                time.sleep(0.4)
                pyautogui.moveTo(694,605)
                pyautogui.click()
                time.sleep(0.5)
                pyautogui.moveTo(get_position('SRstart'))
                pyautogui.click()

                # pyautogui.moveTo(952, 495)
                # pydirectinput.click(952, 495)  # 点击下拉框
                # print("queding")
                #
                # pyautogui.click(get_position4('user1'))
                # time.sleep(1)
                # pyautogui.click(960, 635)
                break


        except pyautogui.ImageNotFoundException:
            time.sleep(1)
            num = num + 1
            print('未找到用户')
            time.sleep(1)
            print("Imag not found ovn the screen. (Caught ImageNotFoundException)")





jdjr=False



def SR_start(word,state):
        global jdjr
        denlu_thread = threading.Thread(target=denlu)
        denlu_thread.start()
        # 应用程序的完整路径
        app_path = r"D:\miHoYo Launcher\games\Star Rail Game\StarRail.exe"

        # 或非阻塞式（不等待程序结束）
        subprocess.Popen(app_path)

        start_event.set()

        while True:
            try:
                if get_position('djjr') is not None:
                    print('已经找到图片')
                    pyautogui.click()
                    djSR=True
                    break
            except pyautogui.ImageNotFoundException:

                print('未找到点击开始')

                time.sleep(0.1)

        SR_YueKa.YueKa(djSR)

        while True:
            try:
                if get_position('rwl') is not None:
                    print('已经找到任务栏')
                    break
            except pyautogui.ImageNotFoundException:
                pyautogui.press('F4')
                print('未找到任务栏')
                time.sleep(1)

        time.sleep(1)

        while True:
           try:
               if get_position('moni') is not None:
                pyautogui.moveTo(get_position('moni'))
                time.sleep(0.5)
                pyautogui.doubleClick()
                time.sleep(2)
                break

           except pyautogui.ImageNotFoundException:

                print('未找到模拟宇宙按键1')

                break
        numbers = Get_NUM.Cless(word)

        int_num = int(numbers[0])




        SR_JR(word,state,int_num)

        pyautogui.press('esc')


        #----------------------------------------------------------好友赠礼--------------------------------------------------------------------#
        SRqianzhen.SRaward()
        #-------------------------------------------------------------委托------------------------------------------------------------------------------------#

        SRweituo.SR_weituo()

        #----------------------------------------------------无名勋章----------------------------------------------------------#

        SRwuming.WUMING()

        # ---------------------------------------------------------------指南--------------------------------------------------------------------
        SRday.Daily_Reward()

        #--------------------------------------------------------------------关闭程序----------------------------------------------------------------------#
        # SR_Year.Yearlinqu()

        # SR_Code.Get_PromoCode()


        SR_account1.SR_USERbku(state)

if __name__ == '__main__':
    SR_start('yiqi',0)

