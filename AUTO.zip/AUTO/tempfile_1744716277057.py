def key_operations():
    global_x = 1670  # 区域横向中心
    global_y = 990
    global action
    reset_flag = False  # 添加重置标志位

    while not stop_event.is_set():
        try:
            if ZZZGetposition.get_position('ZZ') is not None:
                action = 1
                time.sleep(3)
                hold_key('s', 1.2)
                time.sleep(1)
                hold_key('e', 0.4)
                time.sleep(0.5)
                image_detector_Ya()
                break
        except pyautogui.ImageNotFoundException:
            print('未找到')
            time.sleep(0.5)

    while not stop_event.is_set():
        try:
            if 125 < hex_to_grayscale(coloer.get_color_at_position(global_x, global_y)) < 135:
                print('找到e')
                image_detector_Ya()
                hold_key('e', 0.5)
                time.sleep(1)
                hold_key('q', 0.5)
                time.sleep(1)
                image_detector_Ya()
                hold_key('j', 0.5)
                time.sleep(1.893)
                hold_key('j', 0.5)
                time.sleep(1.893)
            else:
                print('未找到e')
            t = 0
            while t < 15 and not stop_event.is_set():
                image_detector_Ya()
                hold_key('j', 0.2)
                time.sleep(0.2)
                print("j攻击")
                t = t + 1

            # 检测到“再来一次”按钮时重置
            if reset_flag:
                reset_flag = False
                key_operations()  # 重新调用 key_operations() 函数
                break  # 退出当前循环

        except Exception as e:
            print(f'发生异常: {e}')
            time.sleep(1)

# 在 image_detector() 函数中设置重置标志位
def image_detector():
    """独立线程：持续检测游戏画面中的按钮"""
    global action
    print(action)
    while not stop_event.is_set():  # 修改为直接检查 stop_event
        if action:
            global The_target_finds
            a = 0
            while not stop_event.is_set() and a < The_target_finds:  # 修改为检测两次后停止
                again_pos = get_position_nonblock('again')
                if again_pos:
                    pyautogui.click(again_pos)
                    time.sleep(5)
                    a += 1
                    print(f'[系统] 检测到再来一次按钮，当前次数：{a}')
                    reset_flag = True  # 设置重置标志位

                queding_pos = get_position_nonblock('queding')
                if queding_pos:
                    pyautogui.click(queding_pos)
                    print('[系统] 检测到确定按钮')

                time.sleep(0.5)  # 增加睡眠时间，降低CPU占用
            while not stop_event.is_set():  # 修改为检测两次后停止
                again_pos2 = get_position_nonblock('wanchen')
                print('[系统] 检测到完成')
                if again_pos2:
                    pyautogui.click(again_pos2)
                    time.sleep(5)
                    a += 1
                    print(f'[系统] 检测到再来一次按钮，当前次数：{a}')
                    stop_event.set()  # 设置stop_event，结束循环
                    break  # 退出循环

            break  # 退出外层循环，确保线程安全退出
        else:
            print('未找到再来一次')
            time.sleep(0.5)
            print("action=", action)
