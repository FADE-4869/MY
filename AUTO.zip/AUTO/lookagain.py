# 寻找指定数量的"again"图片
import time
import pyautogui
def SR_again( target_finds):
        max_attempts = 1000
        The_target_finds=target_finds-1
        print("The_target_finds=" + str(The_target_finds))
        print("target_finds=" + str(target_finds))

        if target_finds>0:

            attempts = 0
            center_finds = 0

            while center_finds < The_target_finds:

                # pyautogui.click(1699,109)
                try:
                    center1 = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/again.png',
                                                            confidence=0.9)
                    if center1:
                        pyautogui.doubleClick(center1)
                        time.sleep(10)
                        print('图片 "again" 已找到并点击')
                        center_finds += 1  # 增加找到center的次数
                except pyautogui.ImageNotFoundException:
                    # 如果没有找到图片，增加尝试次数并等待
                    time.sleep(1)
                    print('未找到图片again，正在重试...')
                    attempts += 1

            time.sleep(4)

            attempts = 0  # 重置尝试次数，因为我们现在开始寻找新的图片
            while attempts < max_attempts:
                try:
                    left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/tuichu.png',
                                                          confidence=0.9)
                    if left:
                        pyautogui.doubleClick(left)

                        print('图片 "tuichu" 已找到并点击，达到目标次数，退出循环')
                        break  # 退出内层循环
                except pyautogui.ImageNotFoundException:
                    # 如果没有找到图片，增加尝试次数并等待
                    print('未找到图片tuichu，正在重试...')
                    time.sleep(1)
                    attempts += 1

            # 如果在内层循环中找到了"tuichu"图片，则跳出外层循环（如果需要的话）
            # 这里假设找到"tuichu"图片后就不需要继续执行了

            # 如果因为达到最大尝试次数而退出循环，则打印一条消息
            if attempts == max_attempts and center_finds < target_finds:
                print(f'达到最大尝试次数 {max_attempts}，但未能在找到足够多的 "again" 图片。')
