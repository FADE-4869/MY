import time

import pyautogui
from pynput.keyboard import Controller

import SR_AUTO
import SR_book
import lookagain
import renwu


def hold_key(key, duration):
    keyboard = Controller()
    keyboard.press(key)
    time.sleep(duration)
    keyboard.release(key)
def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.85)
    return up_left
some_condition=0
target_finds=0
def SR_JR(word2,state, int_num):


    PEIYANG = 0
    YIQI=0
    WM =0
    global target_finds
    global some_condition
    if(state and int_num>90):
        int_num2=int(int_num-90)

        if word2 =="yangchen":
            target_finds =int( int_num2/60)
            PEIYANG=1
        elif word2 =="yiqi":
            target_finds = int(int_num2 /40)
            YIQI=1
        # elif word2 == "weimian":
        #     target_finds = int(int_num2 /40+int_NUM)
        #     WM=1
        if target_finds > 0:
            some_condition = True
        pyautogui.moveTo(466, 450)


        while True:
            try:
                pyautogui.scroll(-10)
                if get_position('zhouben') is not None:
                    print('已经找到图片')
                    pyautogui.click(get_position('zhouben'))
                    break
            except pyautogui.ImageNotFoundException:
                print('未找到点击开始')
                time.sleep(0.1)
        time.sleep(1)
        renwu.SR_rewuXuanZhe('zhoubenYH', 681, 107)#任务
        time.sleep(1)
        pyautogui.moveTo(1617, 989)  # 开始挑战
        time.sleep(1.5)
        pyautogui.doubleClick()
        time.sleep(1.5)
        pyautogui.doubleClick()
        lookagain.SR_again(3)
        pyautogui.click()
        SR_book.SR_book()
        pyautogui.click(get_position('zhinan'))
        time.sleep(1.8)
        pyautogui.click(478,212)

    else:

        if word2 =="yangchen":
            target_finds =int( int_num/60)
            PEIYANG=1
        elif word2 =="yiqi":
            target_finds = int(int_num /40)
            YIQI=1
        # elif word2 == "weimian":
        #     target_finds = int(int_num /40+int_NUM)
        #     WM=1
        The_target_finds =  target_finds  - 1
        print("点击{:d}次again".format(The_target_finds))
        print(The_target_finds)  #点击次数

    if target_finds > 0:
        if PEIYANG:
            # time.sleep(1)
            # renwu.SR_rewuXuanZhe(word2,786,114)
            time.sleep(1)
            pyautogui.click(484, 750)  # 拟造花萼
            time.sleep(1)
            pyautogui.click(1555, 408)
            time.sleep(1)
            while (get_position("tiaozhan")):
                break
            pyautogui.moveTo(1750, 873)  # 最大
            time.sleep(1)
            pyautogui.click()
            time.sleep(1)
            pyautogui.click(1617, 989)  # 开始挑战
            time.sleep(1.5)
            pyautogui.click(1724, 727)
            time.sleep(1.6)
            pyautogui.click(253, 273)  # 好友人物
            time.sleep(1)
            pyautogui.moveTo(1617, 989)  # 开始挑战
            time.sleep(1)
            pyautogui.doubleClick()
            time.sleep(1.5)
            pyautogui.doubleClick()
            time.sleep(3.5)
            some_condition = True
        if YIQI:
            time.sleep(1)
            renwu.SR_rewuXuanZhe(word2, 766, 110)

            while (get_position("tiaozhan")):
                break
            pyautogui.moveTo(1617, 989)  # 开始挑战
            pyautogui.doubleClick()
            time.sleep(1.5)
            pyautogui.click(1724, 727)  # 支援
            time.sleep(1.6)
            pyautogui.click(253, 279)  # 好友人物
            time.sleep(1)
            pyautogui.click(1617, 989)  # 开始挑战
            time.sleep(1)
            pyautogui.doubleClick()
            time.sleep(1.5)
            pyautogui.doubleClick()
            some_condition = True
        if WM:
            pyautogui.click(475, 460)
            time.sleep(1)
            pyautogui.click(1548, 562)
            time.sleep(1)

            while (get_position("StartGame")):
                break
            time.sleep(2)
            pyautogui.moveTo(1617, 989)  # 开始挑战
            time.sleep(2)
            pyautogui.doubleClick()
            time.sleep(5)
            hold_key('w', 3)
            time.sleep(1.5)
            hold_key('2', 0.3)
            time.sleep(1.5)
            hold_key('e', 0.3)
            time.sleep(1.5)
            hold_key('3', 0.3)
            time.sleep(1.5)
            hold_key('e', 0.3)
            time.sleep(1.5)
            hold_key('4', 0.3)
            time.sleep(1.5)
            hold_key('e', 0.3)
            time.sleep(1.5)
            hold_key('1', 0.3)
            time.sleep(1.5)
            hold_key('e', 0.3)
            time.sleep(1.5)
            hold_key('e', 0.3)
            some_condition = True
            time.sleep(2)
        SR_AUTO.SR_coloer_db(some_condition)
        lookagain.SR_again(target_finds)