
import time#pythonproject

import pytesseract
import cv2
import re

import Get_NUM
import NUM_ACR
import SR_AUTO
import SR_Code
import SR_Year
import SR_YueKa
import SR_account20
import SR_coloer
import SR_jinru
import SR_jinru5
import SRday
import SRweituo
import SRwuming
import SRqianzhen
import pyautogui
import Kill_SR

from pynput.keyboard import Controller, Key
import subprocess
import SRswich2
from Account import get_password, get_account, get_word
from SR_jinru0 import SR_JR


def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.85)
    return up_left

def hold_key(key, duration):
    keyboard = Controller()
    keyboard.press(key)
    time.sleep(duration)
    keyboard.release(key)

djSR = False

def SR_USERbku(state):
    global djSR

    code = 19
    print("-------------------------------------------------------SR_account" + str(
        code) + "--------------------------------------------------------------")
    SRswich2.SR_switch(get_password(code), get_account(code))
    djSR = True
    SR_YueKa.YueKa(djSR)
    word = get_word(code)

    while True:
        try:
            if get_position('rwl') is not None:
                print('已经找到任务栏')

                break
        except pyautogui.ImageNotFoundException:
            pyautogui.press('F4')
            print('未找到任务栏')
            time.sleep(2)

    time.sleep(1)

    while True:
        try:
            if get_position('moni') is not None:
                pyautogui.moveTo(get_position('moni'))
                time.sleep(0.5)
                pyautogui.doubleClick()
                time.sleep(2)
                break


        except pyautogui.ImageNotFoundException:

            print('未找到模拟宇宙按键1')

            break

    numbers = Get_NUM.Cless(word)

    int_num = int(numbers[0])

    print(f"共有 {str(numbers)}开括力")

    SR_JR(word, state, int_num)

    pyautogui.press('esc')

    # ----------------------------------------------------------好友赠礼--------------------------------------------------------------------#
    SRqianzhen.SRaward()
    # -------------------------------------------------------------委托------------------------------------------------------------------------------------#

    SRweituo.SR_weituo()

    # ----------------------------------------------------无名勋章----------------------------------------------------------#

    SRwuming.WUMING()

    # ---------------------------------------------------------------指南--------------------------------------------------------------------
    SRday.Daily_Reward()

    # --------------------------------------------------------------------关闭程序----------------------------------------------------------------------#
    # SR_Year.Yearlinqu()
    # SR_Code.Get_PromoCode()

    time.sleep(10)
    SR_account20.SR_USERbku(state)




