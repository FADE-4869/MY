import time
import pyautogui
import keyboard
from threading import Thread, Lock
import ZZZ_coloer
from ZZZ_coloer import get_color_at_position

# 全局控制变量
is_running = False
PAUSE_KEY = 'u'



def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{}.png'.format(word),
                                                 confidence=0.9,region=(1357, 584, 205, 205))
    return up_left
def get_position2(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{}.png'.format(word),
                                                 confidence=0.7,region=(1427, 943, 105, 105))
    return up_left


def toggle_pause():  # ✅ 正确函数名
    """切换暂停状态"""
    global is_running

    while True:

            if  ZZZ_coloer.get_color_at_position(405, 846) == (20, 20, 20):
                print('找到对话框')
                is_running = True
                state = "继续" if is_running else "暂停"
                print(f"程序已 {state}")
                time.sleep(0.1)
            else:
                print('未找到对话框')
                is_running = False
                time.sleep(1)






# 注册热键回调（修复函数名）
keyboard.add_hotkey(PAUSE_KEY, toggle_pause)  # ✅ 使用 toggle_pause


def main_loop():


    print(f"程序启动，按 {PAUSE_KEY} 切换暂停/继续")

    while True:
        try:
            if get_position('test') is not None:
                print('找到任务')
                pyautogui.doubleClick(get_position('test'))
        except pyautogui.ImageNotFoundException:
            try:
                if get_position('Tou') is not None:
                    print('找到Tou')
                    pyautogui.doubleClick(get_position('Tou'))
            except pyautogui.ImageNotFoundException:
                print('未找到Tou')
                print(is_running)
        if is_running:
            pyautogui.click()
            print("space")
            time.sleep(0.1)
        else:
            time.sleep(0.05)
            print('暂停中'+str(is_running))



if __name__ == "__main__":
    main_loop()