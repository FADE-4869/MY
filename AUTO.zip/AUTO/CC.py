import time

import pyautogui
num = 0
while num < 20:
    pyautogui.click(1806,614)
    time.sleep(1)
    pyautogui.click(1781,987)
    num = num + 1