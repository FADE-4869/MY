import sys
from PyQt5.QtWidgets import QApplication, QWidget, QComboBox, QVBoxLayout, QLabel


class LinkedComboBoxes(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        # 创建布局
        layout = QVBoxLayout()

        # 第一个下拉框：主选项
        self.main_combo = QComboBox()
        self.main_combo.addItems(["ZZZ", "SR"])  # 初始选项[2,6](@ref)
        self.main_combo.currentIndexChanged.connect(self.update_sub_combo)  # 绑定事件[6](@ref)

        # 第二个下拉框：子选项
        self.sub_combo = QComboBox()
        self.update_sub_combo(0)  # 初始化默认选项（ZZZ对应的选项）

        # 将控件加入布局
        layout.addWidget(QLabel("主选项："))
        layout.addWidget(self.main_combo)
        layout.addWidget(QLabel("子选项："))
        layout.addWidget(self.sub_combo)

        self.setLayout(layout)
        self.setWindowTitle('关联下拉框示例')
        self.setGeometry(300, 300, 300, 150)

    def update_sub_combo(self, index):
        """根据主选项更新子选项"""
        self.sub_combo.clear()  # 清空原有选项
        selected_main = self.main_combo.currentText()  # 获取当前主选项[6](@ref)

        # 动态填充子选项
        if selected_main == "ZZZ":
            self.sub_combo.addItems(["体力", "钱"])  # ZZZ对应的子项[6](@ref)
        elif selected_main == "SR":
            self.sub_combo.addItems(["遗器", "位面", "养成"])  # SR对应的子项[6](@ref)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = LinkedComboBoxes()
    window.show()
    sys.exit(app.exec_())
