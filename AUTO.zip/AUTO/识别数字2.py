import time
import pyautogui
import cv2
import pytesseract
import re


def get_Num_ACR(x, y, w, h, max_retries=3, retry_interval=1):
    """
    带重试机制的数字识别函数
    参数:
        x, y, w, h: 屏幕区域坐标
        max_retries: 最大重试次数 (默认3次)
        retry_interval: 重试间隔秒数 (默认1秒)
    返回:
        识别到的数字列表 (失败返回空列表)
    """
    for attempt in range(1, max_retries + 1):
        try:
            # 每次尝试都重新截图保证获取最新画面
            screenshot = pyautogui.screenshot(region=(x, y, w, h))
            screenshot_path = 'C:\\Users\\DELL\\PycharmProjects\\AUTO\\resource\\screenshot.png'
            screenshot.save(screenshot_path)

            # 图像预处理
            image = cv2.imread(screenshot_path)
            gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

            # 优化对比度增强参数
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
            enhanced_image = clahe.apply(gray_image)

            # 自适应二值化代替颜色取反
            _, thresh_image = cv2.threshold(enhanced_image, 0, 255,
                                            cv2.THRESH_BINARY + cv2.THRESH_OTSU)

            # 调整识别参数
            text = pytesseract.image_to_string(
                thresh_image,
                config='--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789'
            )

            # 使用更精确的数字匹配规则
            numbers = re.findall(r'\d+', text)
            print(f"第{attempt}次识别结果: {numbers}")

            if numbers:
                return numbers

            print(f"未检测到有效数字，{retry_interval}秒后重试...")
            time.sleep(retry_interval)

        except Exception as e:
            print(f"识别出现异常: {str(e)}")
            time.sleep(retry_interval)

    print(f"已达最大重试次数{max_retries}次，停止检测")
    return []


# 使用示例
numbers = get_Num_ACR( 624, 726, 56, 37)
if numbers:
    print("最终识别结果:", numbers)
else:
    print("未能识别到数字")
