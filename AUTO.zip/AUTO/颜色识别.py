from PIL import ImageGrab
import pyautogui
import time


def rgb_to_hex(rgb):
    return '{:02x}{:02x}{:02x}'.format(*rgb)


def get_color_at_position(global_x, global_y):
    # 定义固定的截图区域
    region_x, region_y, region_w, region_h = 1629, 925, 85, 85

    # 校验全局坐标是否在区域内
    if not (region_x <= global_x <= region_x + region_w and
            region_y <= global_y <= region_y + region_h):
        return None, "坐标超出截图区域"

    # 转换为局部坐标
    local_x = global_x - region_x
    local_y = global_y - region_y
    print(local_x, local_y)
    # 截取区域并获取颜色
    try:
        screenshot = pyautogui.screenshot(region=(region_x, region_y, region_w, region_h))
        rgb = screenshot.getpixel((local_x, local_y))
        return rgb, rgb_to_hex(rgb)
    except Exception as e:
        return None, str(e)


# 测试：获取区域内的一个点（例如区域中心点）
global_x = 1670  # 区域横向中心
global_y = 990   # 区域纵向中心
rgb, hex_color = get_color_at_position(global_x, global_y)

if rgb:
    print(f"颜色值: RGB={rgb}, HEX={hex_color}")
else:
    print(f"错误: {hex_color}")










