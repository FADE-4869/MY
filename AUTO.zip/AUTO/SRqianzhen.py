
import pyautogui
import time
import SR_book
def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.9)
    return up_left
def  SRaward():
    SR_book.SR_book()
    num1=0
    while num1 <4:
        try:
            if get_position('gift') is not None:
                pyautogui.moveTo(get_position('gift'))
                pyautogui.click()
                time.sleep(1)
                pyautogui.moveTo(get_position('manyou'))
                pyautogui.click()
                time.sleep(1)
                pyautogui.moveTo(get_position('Fgift'))
                pyautogui.click()
                break
        except pyautogui.ImageNotFoundException:

            print('未找到（。。。）')
            time.sleep(1.5)
            num1=num1+1
    # pyautogui.moveTo(1727, 112)#(...)

    SR_book.SR_book()
    # pyautogui.moveTo(1680, 279)#（gift）
    # time.sleep(2)
if __name__ == '__main__':
    SRaward()
