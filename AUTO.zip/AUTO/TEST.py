import logging
import time

import pyautogui
import pydirectinput

from SRswich2 import get_positionX, get_position3

# 配置日志记录
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# 最大重试次数
MAX_RETRIES = 10
retry_count = 0
while retry_count < MAX_RETRIES:
    try:
        if get_positionX('userswish') is not None:
            logging.info('已经找到MHY')

            pydirectinput.click(952, 495)
            time.sleep(3)

            logging.info("queding")
            while True:
                try:
                    if get_position3('192') is not None:
                        pyautogui.doubleClick(get_position3('192'))
                        time.sleep(1)
                        pyautogui.click(960, 635)
                        break

                except pyautogui.ImageNotFoundException:
                    logging.warning('未找到用户')
                    time.sleep(1)

    except pyautogui.ImageNotFoundException:
        pyautogui.click(1829, 178)  # 登录
        time.sleep(1)
        pyautogui.click(1087, 688)
        time.sleep(2)