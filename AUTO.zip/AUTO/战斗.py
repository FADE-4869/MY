import threading
import time
import pyautogui
from pynput.keyboard import Controller, Key

import ZZZGetposition
state=0
keyboard = Controller()
def hold_key(key, duration):
    keyboard.press(key)
    time.sleep(duration)
    keyboard.release(key)
def stop_thread(detector_thread, operator_thread):
    """停止线程"""

    detector_thread.join(timeout=1)  # 等待线程结束
    operator_thread.join(timeout=1)
    print("主线程已安全退出")
def hold_mouse(duration):
    pyautogui.mouseDown()
    time.sleep(duration)
    pyautogui.mouseUp()
def image_detector_Ya():
    while True:
        try:
            if ZZZGetposition.get_position('ya') is not None:
                print('找到ya')
                break
            else:
                print('未找到ya')
                hold_key(Key.space, 0.4)
        except pyautogui.ImageNotFoundException:
            hold_key(Key.space, 0.2)
            time.sleep(0.5)
def image_detector_Kai():

    while True:
        try:
            if ZZZGetposition.get_position('Kai') is not None:
                print('找到Kai')
                break
            else:
                print('未找到Kai')
                hold_key(Key.space, 0.4)
        except pyautogui.ImageNotFoundException:
            hold_key(Key.space, 0.2)
            time.sleep(0.5)





def image_detector():
    """独立线程：持续检测游戏画面中的按钮"""
    global state
    a=0  
    while True:
        try:
            if ZZZGetposition.get_position('again') is not None:
                pyautogui.click(ZZZGetposition.get_position('again'))
                a+=1
                state = 3
                print(f'[系统] 检测到再来一次按钮，当前次数：{a}')
            elif ZZZGetposition.get_position('queding') is not None:
                pyautogui.click(ZZZGetposition.get_position('queding'))
                print('[系统] 检测到确定按钮')
                time.sleep(0.5)  # 增加睡眠时间，降低CPU占用

        except pyautogui.ImageNotFoundException:
            print('寻找again')
            time.sleep(0.5)
    while True:
        try:
            if ZZZGetposition.get_position('wanchen') is not None:
                pyautogui.click(ZZZGetposition.get_position('wanchen'))
                break
        except pyautogui.ImageNotFoundException:
            print('寻找wanchen')
            time.sleep(0.5)
def key_operations():
    global state
    state=3
    while True:
        screenshot = pyautogui.screenshot(region=(0,0,1920 ,1080))
        match state:
            case 3:
                    image_detector_Kai()
                    print("执行 case3")
                    time.sleep(1)
                    hold_key('e', 0.5)
                    state = 1
            case 1:
                   image_detector_Ya()
                   time.sleep(2)
                   print("执行 case1")
                   hold_key('e', 0.5)
                   time.sleep(1)
                   hold_key('j', 0.5)
                   time.sleep(1.893)
                   hold_key('j', 0.5)
                   time.sleep(1.893)
                   time.sleep(1)
                   state = 2
                   print("执行 case1")

            case 2:

                if  screenshot.getpixel((1643, 968))[0]>200:
                  state = 1
                hold_mouse(0.2)
                print("执行 case2")


def ZZZ_main():
    # global The_target_finds
    # stop_event.clear()
    # keyboard = Controller()
    # time.sleep(3)
    # ZZZbook.ZZZ_book()
    # time.sleep(1.8)
    # pyautogui.click(1169, 151)
    # time.sleep(1.8)
    # position = (1034, 221, 130, 40)
    # int_num = ZZZ_NUM.get_position_nonblock(position)
    # int_num_ZZZ = int(int_num[0])
    #
    # # int_NUM=int(numbers2[0])
    # target_finds = int(int_num_ZZZ / 100)
    #
    # The_target_finds = target_finds
    # # print(f"共有 {int_num1 }额外开括力")
    # print(f"共有 {int_num}开括力")
    #
    # # print(f"共有 {int_NUM }沉浸器")
    #
    # print("有{:d}次".format(target_finds))  # 转化后的沉浸器
    # print(The_target_finds)  # 点击次数
    #
    # if The_target_finds > 0:
    #     pyautogui.click(1173, 146)
    #     time.sleep(1.8)
    #     pyautogui.click(1474, 437)
    #     time.sleep(1.8)
    #     ZZZKO.queding()
    #     time.sleep(5)
    #     keyboard.press(Key.esc)
    #     time.sleep(1.8)
    #     pyautogui.click(1439, 510)
    #     time.sleep(1.8)
    #     pyautogui.click(1290, 825)
    #     time.sleep(2)
    #     pyautogui.click(1721, 1027)
    #     time.sleep(2)
    #     pyautogui.click(1721, 1027)
    #     time.sleep(1)
    #
    #     # 启动检测线程
        detector_thread = threading.Thread(target=image_detector)
        detector_thread.daemon = True  # 设为守护线程

        # 启动操作线程
        operator_thread = threading.Thread(target=key_operations)
        operator_thread.daemon = True

        try:
            detector_thread.start()
            operator_thread.start()
            print('[系统] 所有线程已启动，按CTRL+C停止')


            while True:  # 保持主线程运行
                time.sleep(1)

        except KeyboardInterrupt:
            print('[系统] 正在停止所有线程...')

            detector_thread.join(timeout=1)
            operator_thread.join(timeout=1)
            print('[系统] 已安全退出')
        stop_thread(detector_thread, operator_thread)

        # 确保线程退出后再执行以下操作

        print("程序结束")
if __name__ == '__main__':
    ZZZ_main()