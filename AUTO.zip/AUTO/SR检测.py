import pyautogui
import time
import pyautogui
import keyboard

import renwu



time.sleep(1)
renwu.SR_rewuXuanZhe("yiqi" ,766, 110)
pyautogui.moveTo(1617, 989)  # 开始挑战
pyautogui.doubleClick()
time.sleep(1.5)
pyautogui.click(1724, 727)  # 支援
time.sleep(1.6)
pyautogui.click(253, 544)  # 好友人物
time.sleep(1)
pyautogui.click(1617, 989)  # 开始挑战
time.sleep(1)
pyautogui.doubleClick()
time.sleep(1.5)
pyautogui.doubleClick()