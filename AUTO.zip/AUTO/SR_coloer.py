from PIL import ImageGrab
import pyautogui
import time


# def rgb_to_hex(rgb):
#     return '#{:02x}{:02x}{:02x}'.format(*rgb)

def hex_to_grayscale(hex_color):
    r, g, b = hex_color
    return (r + g + b) // 3  # 简单平均值
def get_color_at_position(global_x, global_y):
    # 定义固定的截图区域
    region_x, region_y, region_w, region_h = 1708, 25, 100, 40

    # 校验全局坐标是否在区域内
    if not (region_x <= global_x <= region_x + region_w and
            region_y <= global_y <= region_y + region_h):
        return None, "坐标超出截图区域"

    # 转换为局部坐标
    local_x = global_x - region_x
    local_y = global_y - region_y

    # 截取区域并获取颜色
    try:
        screenshot = pyautogui.screenshot(region=(region_x, region_y, region_w, region_h))
        rgb = screenshot.getpixel((local_x, local_y))
        value=  hex_to_grayscale(rgb)

        return value
    except Exception as e:
        return None, str(e)










