import threading
import time
import pyautogui
from pynput.keyboard import Controller, Key

import ZZZGetposition
import coloer

import ZZZV4
Shared_Click = 0
lock = threading.Lock()  # 创建锁jj
Click  =False    # 标志位，用于控制 click() 的暂停和恢复
Key_operations  = True

def hex_to_grayscale(hex_color):
    r, g, b = hex_color
    return (r + g + b) // 3  # 简单平均值
def hold_key(key, duration):
    keyboard = Controller()
    keyboard.press(key)
    time.sleep(duration)
    keyboard.release(key)

def image_detector_Kai():
    global Click
    while  True:

            try:
                if ZZZGetposition.get_position('Kai') is not None:
                    print('找到Kai')

                else:
                    print('未找到Kai')
                    hold_key(Key.space, 0.4)
            except pyautogui.ImageNotFoundException:
                hold_key(Key.space, 0.2)
                time.sleep(0.5)


            try:
                if ZZZGetposition.get_position('ya') is not None:
                    print('找到ya')

                else:
                    print('未找到ya')
                    hold_key(Key.space, 0.4)




        #     try:
        #         if ZZZGetposition.get_position('ZZ') is not None:
        #             action = 1
        #             time.sleep(3)
        #             hold_key('s', 1.2)
        #             time.sleep(1)
        #             hold_key('e', 0.4)
        #             time.sleep(0.5)
        #             break
        #     except pyautogui.ImageNotFoundException:
        #         print('未找到')
        #         time.sleep(0.5)
            print(coloer.get_color_at_position(743, 73))
            try:
                  if hex_to_grayscale(coloer.get_color_at_position(743, 73))!=  64:

                    # 获取锁，暂停 click()
                    Click = False

                    image_detector_Kai()
                    time.sleep(1)
                    hold_key('e', 0.4)
                    print('e')
                    Click = True

            except pyautogui.ImageNotFoundException:
                print('未找到')
                time.sleep(0.5)




            if ZZZV4.hex_to_grayscale(coloer.get_color_at_position(455, 47)) != 64:
                Click = False
                print('找到e')
                image_detector_Ya()
                ZZZV4.hold_key('e', 0.5)
                time.sleep(1)
                ZZZV4.hold_key('q', 0.5)
                time.sleep(1)
                ZZZV4.image_detector_Ya()
                ZZZV4.hold_key('j', 0.5)
                time.sleep(1.893)
                ZZZV4.hold_key('j', 0.5)
                time.sleep(1.893)
                Click = True
            else:
                print('未找到e')



            if  Click:
                print("Click: "+str(Click))
                ZZZV4.image_detector_Ya()
                ZZZV4.hold_key('j', 0.2)
                time.sleep(0.2)
                print("j攻击")
