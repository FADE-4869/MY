# import time
#
# import cv2
# import pyautogui
# import pytesseract
# import re
#
# def get_Num_ACR(x, y, w, h, max_retries=4, retry_interval=1):
#     """
#     带重试机制的数字识别函数
#     参数:
#         x, y, w, h: 屏幕区域坐标
#         max_retries: 最大重试次数 (默认3次)
#         retry_interval: 重试间隔秒数 (默认1秒)
#     返回:
#         识别到的数字列表 (失败返回空列表)
#     """
#     for attempt in range(1, max_retries + 1):
#
#         try:
#             # 每次尝试都重新截图保证获取最新画面
#             screenshot = pyautogui.screenshot(region=(x, y, w, h))
#             screenshot_path = 'C:\\Users\\DELL\\PycharmProjects\\AUTO\\resource\\screenshot.png'
#             screenshot.save(screenshot_path)
#
#             # 图像预处理
#             image = cv2.imread(screenshot_path)
#             gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
#
#             # 优化对比度增强参数
#             clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
#             enhanced_image = clahe.apply(gray_image)
#
#             # 自适应二值化代替颜色取反
#             _, thresh_image = cv2.threshold(enhanced_image, 0, 255,
#                                             cv2.THRESH_BINARY + cv2.THRESH_OTSU)
#
#             # 调整识别参数
#             text = pytesseract.image_to_string(
#                 thresh_image,
#                 config='--oem 2 --psm 7 -c tessedit_char_whitelist=0123456789'
#             )
#
#             # 使用更精确的数字匹配规则
#             numbers = re.findall(r'\d+', text)
#             print(f"第{attempt}次识别结果: {numbers}")
#
#             if numbers:
#                 return numbers
#
#             print(f"未检测到有效数字，{retry_interval}秒后重试...")
#             time.sleep(retry_interval)
#
#         except Exception as e:
#             print(f"识别出现异常: {str(e)}")
#             time.sleep(retry_interval)
#
#     print(f"已达最大重试次数{max_retries}次，停止检测")
#     return []
import time
import pyautogui
import cv2
import pytesseract
import re
import numpy as np
from collections import Counter


class DigitRecognitionError(Exception):
    """自定义数字识别异常"""
    pass


def adaptive_dilation(image):
    """自适应形态学处理"""
    horizontal_projection = np.sum(image, axis=0)
    zero_columns = np.where(horizontal_projection == 0)[0]

    if len(zero_columns) > 2:
        spacing = np.mean(np.diff(zero_columns))
        kernel_size = 2 if spacing > 5 else 3
    else:
        kernel_size = 3

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_size, 1))
    return cv2.dilate(image, kernel, iterations=1)


def preprocess_image(image):
    """强化图像预处理流水线"""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)
    _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    processed = adaptive_dilation(binary)
    return cv2.medianBlur(processed, 3)


def validate_result(text):
    """严格结果验证"""
    clean_text = text.replace('O', '0').replace('o', '0').strip()
    if re.fullmatch(r'\d{1,3}', clean_text):
        number = int(clean_text)
        return min(max(number, 0), 400)  # 限制在0-400范围
    return None


def get_Num_ACR(x, y, w, h, max_retries=3, retry_interval=1):
    """三次识别取多数结果版本"""
    recognition_configs = [
        '--oem 2 --psm 7',  # LSTM引擎+单行模式
        '--oem 2 --psm 8',  # LSTM引擎+单词模式
        '--oem 1 --psm 13'  # 传统引擎+原始行
    ]

    for attempt in range(1, max_retries + 1):
        try:
            # 单次尝试中进行三次独立识别
            screenshot = pyautogui.screenshot(region=(x, y, w, h))
            image = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
            processed = preprocess_image(image)

            results = []
            for config in recognition_configs:
                full_config = (
                    f'{config} '
                    '-c tessedit_char_whitelist=0123456789 '
                    'load_system_dawg=0 load_freq_dawg=0'
                )

                # 三次识别可能产生不同结果
                text = pytesseract.image_to_string(processed, config=full_config)
                if num := validate_result(text):
                    results.append(num)

            print(f"第{attempt}次识别结果集: {results}")

            # 结果统计决策
            if results:
                counter = Counter(results)
                most_common = counter.most_common(1)

                # 最高频结果出现2次以上则采纳
                if most_common[0][1] >= 2:
                    return [most_common[0][0]]

                # 出现多个不同结果时，优先返回最大合理值
                if len(counter) > 1:
                    return [min(max(results), 400)]

            raise DigitRecognitionError("未达成多数共识")

        except DigitRecognitionError as e:
            print(f"第{attempt}次尝试未达成共识: {str(e)}")
            time.sleep(retry_interval)

        except Exception as e:
            print(f"系统异常: {str(e)}")
            time.sleep(retry_interval)

    print(f"已达最大重试次数{max_retries}次")
    return []


# 测试用例
if __name__ == "__main__":
    # 测试400的稳定识别
    print("测试400识别:")
    print(get_Num_ACR(100, 200, 300, 400))

    # 测试混合结果
    print("\n测试混合结果[300, 300, 400]:")
    print("预期输出300，实际输出:", [300] if [300] == get_Num_ACR(100, 200, 300, 400) else "失败")
