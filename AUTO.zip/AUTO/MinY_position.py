import pyautogui
# def list_position(word):
#     all_targets = list(pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
#                                                      confidence=0.85))
#
#     if not all_targets:
#         print("未找到目标")
#     else:
#         print(all_targets)
#         # 按Y轴坐标排序（屏幕坐标系原点在左上角，Y值越大位置越靠下）
#         # 假设all_targets中的元素是包含top属性的对象
#         sorted_targets = sorted(all_targets, key=lambda box: box.top)
#         y_min_target = sorted_targets[0]
#         center_x, center_y = pyautogui.center(y_min_target)
#         print(f"Y轴最小坐标：({center_x}, {center_y})")
def get_positionZ(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.85,region=(1422,444, 300, 200))
    return up_left

pyautogui.doubleClick(get_positionZ('MoveTo'))

