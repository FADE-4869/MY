import time
import pyautogui
import keyboard
from Getposition import get_position  # 假设自定义模块
import SRKO
import SR_book

CONFIG = {
    "claim_reward": (431, 907),  # 领取奖励的屏幕坐标
    "reassign": (1215, 966),  # 重新委托的屏幕坐标
    "max_retries": 5  # 最大重试次数
}


def SR_weituo():



    while True:
        try:
            if (pos := get_position('weituo')) is not None:
                pyautogui.click(pos)
                time.sleep(1)
                break

        except pyautogui.ImageNotFoundException:
            print("未找到委托1，尝试重试...")
            pyautogui.press('esc')

            time.sleep(2)

    # 如果达到最大重试次数仍未找到委托任务，则中止操作
    while True:
        try:
            if (pos := get_position('yjlq')) is not None:
                pyautogui.click(pos)
                time.sleep(1.2)
                pyautogui.click(get_position('zcpq'))
                time.sleep(2)
                print("再次派遣")
                break



        except pyautogui.ImageNotFoundException:
            print("操作执行失败未找到领取奖励，通过找回再次派遣")

            time.sleep(1)
            try:
                if  get_position('zhaohui') is not None:
                    pyautogui.click(get_position('zhaohui'))
                    time.sleep(1)
                    SRKO.queding()
                    pyautogui.moveTo(1493,792)
                    time.sleep(0.5)
                    pyautogui.click(1493,792)
                    time.sleep(1)
                    pyautogui.moveTo(363, 395 )
                    time.sleep(0.5)
                    pyautogui.click(363, 395)
                    time.sleep(1)

                    pyautogui.click(502, 398)
                    time.sleep(1)
                    pyautogui.click(1447, 910)
                    break
            except pyautogui.ImageNotFoundException:
                print("没有召回直接派遣")
                pyautogui.moveTo(1493, 792)
                time.sleep(0.5)
                pyautogui.click(1493, 792)
                time.sleep(1)
                pyautogui.moveTo(363, 395)
                time.sleep(0.5)
                pyautogui.click(363, 395)
                time.sleep(1)

                pyautogui.click(502, 398)
                time.sleep(1)
                pyautogui.click(1447, 910)
                break




    SR_book.SR_book()

# 无论成功与否，最后按下ESC键以确保退出当前界面
if __name__ == "__main__":
    SR_weituo()



