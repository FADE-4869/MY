from PyQt5 import QtCore
from PyQt5.QtCore import QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QPainter, QLinearGradient, QColor
from PyQt5.QtWidgets import (QWidget, QPushButton, QComboBox)


class MainWindow(QWidget):
    WINDOW_TITLE = 'PyQt5基础框架'
    WINDOW_GEOMETRY = (300, 300, 300, 200)
    COMBO_OPTIONS = [
        ('遗器', 'yiqi'),
        ('养成', 'peiyan'),
        ('面位饰品', 'weimian')
    ]

    def __init__(self):
        super().__init__()
        self.btn_anim = None
        self.init_ui()
        self.create_connections()
        self.setup_animations()

    def setup_animations(self):
        """ 初始化按钮放大动画 """
        self.hover_anim = QPropertyAnimation(self.btn_start, b"geometry")
        self.hover_anim.setDuration(300)  # 动画持续时间为 300 毫秒
        self.hover_anim.setEasingCurve(QEasingCurve.InOutQuad)  # 使用缓动曲线

        # 初始化按钮点击动画
        self.btn_anim = QPropertyAnimation(self.btn_start, b"geometry")
        self.btn_anim.setDuration(200)
        self.btn_anim.setEasingCurve(QEasingCurve.OutQuad)

    def _start_animation(self, start_value, end_value):
        """ 启动动画的私有方法 """
        self.hover_anim.setStartValue(start_value)
        self.hover_anim.setEndValue(end_value)
        self.hover_anim.start()

    def enterEvent(self, event):
        """ 鼠标进入按钮区域时触发 """
        original = self.btn_start.geometry()
        new_geometry = original.adjusted(-5, -5, 5, 5)  # 放大 20px
        self._start_animation(original, new_geometry)

    def leaveEvent(self, event):
        """ 鼠标离开按钮区域时触发 """
        original = self.btn_start.geometry()
        self._start_animation(original, original)  # 恢复到原始尺寸

    def paintEvent(self, event):
        """ 绘制渐变背景 """
        painter = QPainter(self)
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0.0, QColor(30, 32, 45))  # 起始颜色
        gradient.setColorAt(1.0, QColor(65, 68, 90))  # 结束颜色
        painter.fillRect(self.rect(), gradient)

    def on_start_clicked(self):
        """ 添加按钮点击动画 """
        original = self.btn_start.geometry()
        self.btn_anim.setStartValue(original.adjusted(0, 5, 0, 0))
        self.btn_anim.setEndValue(original)
        self.btn_anim.start()
        # 原有业务逻辑保持不变...

    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle(self.WINDOW_TITLE)
        self.setGeometry(*self.WINDOW_GEOMETRY)

        self.create_widgets()
        self.setup_layout()

    def create_widgets(self):
        """
        初始化并配置界面控件

        创建组合框和开始按钮控件，并使用预定义的选项数据初始化下拉框。
        控件直接挂载到父窗口，通过类成员变量保存控件引用。
        """
        self.combobox = QComboBox()
        self.btn_start = QPushButton('开始', self)

        # 使用COMBO_OPTIONS元组数据初始化下拉框选项
        for display_text, user_data in self.COMBO_OPTIONS:
            self.combobox.addItem(display_text, user_data)

        # 动态按钮样式
        self.btn_start.setStyleSheet('''
                QPushButton {
                    background-color: #6d9ec5;  /* 默认背景颜色 */
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 5px;
                    font-size: 14px;
                    transition: background-color 1s ease;  /* 颜色变化的过渡效果 */
                }
                QPushButton:hover {
                background: qlineargradient(
                    x1:0, y1:0, x2:1, y2:1,
                    stop:0 #6d9ec5,
                    stop:1 #f5bfc9
                    );
                }

                QPushButton:pressed {
                    background-color: #3C3F54;  /* 按下时的背景颜色 */
                }
            ''')

        self.btn_start.setCursor(QtCore.Qt.CursorShape.PointingHandCu)