import win32gui
hwnd = win32gui.GetForegroundWindow()  # 获取当前活动窗口句柄
title = win32gui.GetWindowText(hwnd)    # 标题
rect = win32gui.GetWindowRect(hwnd)    # 位置和尺寸（左上/右下坐标）

def enum_windows_callback(hwnd, windows):
    if win32gui.IsWindowVisible(hwnd):
        title = win32gui.GetWindowText(hwnd)
        windows.append((hwnd, title))
windows = []
win32gui.EnumWindows(enum_windows_callback, windows)


if __name__ == '__main__':
    print(windows)