import time  #pythonproject
import pyautogui


from pynput.keyboard import Controller
keyboard = Controller()

import Getposition

# pytesseract.pytesseract.tesseract_cmd = r'C:\Users\DELL\AppData\Local\Programs\Tesseract-OCR'
access_attempts=2

def queding():
    i=0
    while i<5:
        try:
            if Getposition.get_position('SRqueding') is not None:
                pyautogui.moveTo(Getposition.get_position('SRqueding'))
                pyautogui.click()
                print('找到确定')
                break
        except pyautogui.ImageNotFoundException:
            time.sleep(1)
            i=i+1
            print('未找到确定')

#ifndef __USER_MAIN_H_
#define __USER_MAIN_H_
#include "debug.h"
#define LED0_GPIO_PORT GPIOA
#define LED0_GPIO_PIN  GPIO_Pin_15
#define LED1_GPIO_PORT GPIOB
#define LED1_GPIO_PIN  GPIO_Pin_4

#define EWR_GPIO_PORT GPIOA
#define EWR_GPIO_PIN  GPIO_Pin_1
#define EWY_GPIO_PORT GPIOA
#define EWY_GPIO_PIN  GPIO_Pin_2
#define EWG_GPIO_PORT GPIOA
#define EWG_GPIO_PIN  GPIO_Pin_3

#define SNR_GPIO_PORT GPIOE
#define SNR_GPIO_PIN  GPIO_Pin_1
#define SNY_GPIO_PORT GPIOE
#define SNY_GPIO_PIN  GPIO_Pin_2
#define SNG_GPIO_PORT GPIOE
#define SNG_GPIO_PIN  GPIO_Pin_3

#endif