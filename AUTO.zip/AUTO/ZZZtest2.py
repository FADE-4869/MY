import time  #pythonproject
import pyautogui
from pynput.keyboard import Controller, Key

import ZZZV4
import ZZZV5

keyboard = Controller()
import ZZZKO
import subprocess
access_attempts=2
import ZZZbook
import threading
import Kill_SR

def hold_key(key, duration):
    controller = Controller()
    controller.press(key)    # 按下
    time.sleep(duration)     # 保持
    controller.release(key)  # 释放

# 正确调用方式（注意要用 Key.esc）


def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{}.png'.format(word),confidence=0.85 )
    return up_left
#
#

def ZZZdenlu():
    # # 应用程序的完整路径
    # app_path = r"D:\miHoYo Launcher\games\ZenlessZoneZero Game\ZenlessZoneZero.exe"
    #
    # #     或非阻塞式（不等待程序结束）
    # subprocess.Popen(app_path)

    time.sleep(2) 

    num=0
    while num<120:
            try:
                if pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/using.png',
                                                 confidence=0.9,region=(681, 759, 543, 116)) is not None:
                        pyautogui.moveTo(get_position('using'))
                        pyautogui.click()
                        time.sleep(1.5)
                        pyautogui.moveTo(get_position('password'))
                        pyautogui. click()
                        pyautogui.write('123456kzy')
                        time.sleep(0.8)
                        pyautogui.moveTo(get_position('phone'))
                        time.sleep(0.8)
                        pyautogui.doubleClick()
                        pyautogui.write('18771916560')
                        time.sleep(0.8)
                        pyautogui.moveTo(get_position('00'))
                        pyautogui.click()
                        time.sleep(0.6)
                        pyautogui.moveTo(get_position('ZZZstart'))
                        pyautogui.click()
                        break
                else:
                        print("Image not found on the screen.")


            except pyautogui.ImageNotFoundException:
                time.sleep(2)
                num=num+1
                print("Imag not found ovn the screen. (Caught ImageNotFoundException)")
            # try:
            #     if pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{}.png'.format('djjr2'),confidence=0.9) is not None:
            #             pyautogui.doubleClick(get_position('djjr2'))
            #
            #             break
            #     else:
            #             print("Image not found on the screen,start game.")
            #
            #
            # except pyautogui.ImageNotFoundException:
            #     time.sleep(2)
            #     num=num+1
            #     print("Imag not found ovn the screen. (Caught ImageNotFoundException)")
def ZZZtest2():
    denlu_thread =threading.Thread(target=ZZZdenlu)
    denlu_thread.start()



    while True:
        try:
            if get_position('ZZZdjjr') is not None:
                print('已经找到图片')
                pyautogui.click()

                break
        except pyautogui.ImageNotFoundException:

            print('未找到点击开始2')

            time.sleep(0.1)

    time.sleep(10)

    ZZZbook.ZZZ_book()
    time.sleep(1.5)
    pyautogui.moveTo(966,834)
    pyautogui.click()
    time.sleep(1.5)
    pyautogui.moveTo(1126,634)
    pyautogui.click()
    time.sleep(2)


    MAX_ATTEMPTS = 5
    attempts = 0

    while attempts<15:
        try:
            # 假设 get_position 在找不到时抛出 ImageNotFoundException
            if get_position('daindan') is not None:
                print('找到')
                pyautogui.doubleClick(get_position('daindan'))
                time.sleep(1)
                pyautogui.doubleClick()
                break
        except pyautogui.ImageNotFoundException:
            print('无法找到')
            attempts += 1
            time.sleep(1)



    # pyautogui.moveTo(get_position('daindan'))
    # pyautogui.click()
    # time.sleep(1.2)
    # # pyautogui.moveTo(get_position('queding'))
    # pyautogui.click()

    # while True:
    #     try:
    #         if get_position('tiaoguo') is not None:
    #             print('找到跳过')
    #             pyautogui.doubleClick(get_position('tiaoguo'))
    #             time.sleep(2)
    #             ZZZKO.queding()
    #             break
    #     except pyautogui.ImageNotFoundException:
    #         print('无法找到')
    #         attempts += 1
    #         time.sleep(1)
    #     except Exception as e:
    #         print(f'发生未预料异常: {str(e)}')
    #         break




    while True:
        try:
            if get_position('zhu') is not None:
                print('回到主页面')
                break
        except pyautogui.ImageNotFoundException:
            hold_key(Key.esc, 0.5)

            print('未找到主页面')

            time.sleep(1)
    # -----------------------------------------------------------------------

    time.sleep(1)
    ZZZbook.ZZZ_book()
    time.sleep(1.5)
    pyautogui.click(966,834)

    time.sleep(1.5)
    pyautogui.click(1126,634)

    time.sleep(3)

    pyautogui.click(136,945)

    time.sleep(1)
    pyautogui.doubleClick(804,544)

    # 向右移动（正弦波实现平滑）
    pyautogui.click()
    pyautogui.mouseDown(button="left")

    pyautogui.moveRel(317, 0, duration=1,tween=pyautogui.easeInOutQuad)
    pyautogui.moveRel(-305, 41, duration=1, tween=pyautogui.easeInOutQuad)
    pyautogui.moveRel(317, 0,duration=1, tween=pyautogui.easeInOutQuad)
    pyautogui.moveRel(-305, 41, duration=1, tween=pyautogui.easeInOutQuad)

    pyautogui.mouseUp(button="left")
    time.sleep(1)
    ZZZKO.queding()
    time.sleep(0.5)
    pyautogui.doubleClick(1396,521)
    time.sleep(1)
    while True:
        try:
            if get_position('zhu') is not None:
                print('回到主页面')
                break
        except pyautogui.ImageNotFoundException:
            keyboard.press(Key.esc)
            print('未找到主页面')

            time.sleep(0.2)


    # -----------------------------------------------------------------------
    time.sleep(5)
    ZZZbook.ZZZ_book()
    time.sleep(1.5)
    pyautogui.moveTo(966,834)

    time.sleep(1)
    # pyautogui.click(pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/qianwang.png',
    #                                                  confidence=0.85,region=(844,802,246,72)))
    pyautogui.click(928,840)
    ZZZKO.queding()
    pyautogui.click()
    time.sleep(4)
    pyautogui.moveTo(136,945)
    pyautogui.click()
    time.sleep(1.5)
    pyautogui.moveTo(903,753)
    pyautogui.click()
    time.sleep(1)
    pyautogui.moveTo(1683,1028)
    pyautogui.click()
    time.sleep(1)
    pyautogui.moveTo(1183,753)
    pyautogui.click()
    time.sleep(1)
    pyautogui.moveTo(1414,1022)
    pyautogui.click()
    time.sleep(1)
    pyautogui.moveTo(1666,976)
    pyautogui.click()
    time.sleep(1)
    ZZZKO.queding()
    pyautogui.click()
    time.sleep(2)
    while True:
        try:
            if get_position('zhu') is not None:
                print('回到主页面')
                break
        except pyautogui.ImageNotFoundException:
            hold_key(Key.esc, 0.5)

            print('未找到主页面')

            time.sleep(0.5)

    time.sleep(3)
    while True:
        try:
            if get_position('book') is not None:
                print('回到手册面')
                break
        except pyautogui.ImageNotFoundException:
            hold_key(Key.f2, 0.5)

            print('未找到手册面')

            time.sleep(1)
    time.sleep(1.5)
    pyautogui.moveTo(979,139)
    pyautogui.click()
    time.sleep(1.5)
    pyautogui.moveTo(846,270)
    pyautogui.click()
    time.sleep(1)
    ZZZKO.queding()
    pyautogui.click()
    time.sleep(1)
    while True:
        try:
            if get_position('zhu') is not None:
                print('回到主页面')
                break
        except pyautogui.ImageNotFoundException:
            hold_key(Key.esc, 0.5)

            print('未找到主页面')

            time.sleep(1)
    # ---------------------------------------------------------------------
    time.sleep(4)
    keyboard.press('i')
    time.sleep(2)
    pyautogui.moveTo(1495,49)
    pyautogui.click()
    time.sleep(1.2)
    pyautogui.moveTo(1721,1027)
    pyautogui.click()
    time.sleep(1.3)
    pyautogui.moveTo(1260,53)
    pyautogui.click()
    time.sleep(1.3)
    pyautogui.moveTo(1363,1029)
    pyautogui.click()
    time.sleep(2)
    # pyautogui.moveTo(get_position('return'))
    pyautogui.click()
    time.sleep(2)
    while True:
        try:
            if get_position('zhu') is not None:
                print('回到主页面')
                break
        except pyautogui.ImageNotFoundException:
            hold_key(Key.esc, 0.5)

            print('未找到主页面')

            time.sleep(0.5)
    ZZZV5.ZZZ_main()



