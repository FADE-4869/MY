import sys
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout,
                             QPushButton, QComboBox, QRadioButton, QLabel)
import SR_account


class MainWindow(QWidget):
    WINDOW_TITLE = 'PyQt5基础框架'
    WINDOW_GEOMETRY = (300, 300, 300, 200)

    def __init__(self):
        super().__init__()
        self.state = False  # 用于存储单选框的状态
        self.game = None
        self.function = None
        self.init_ui()
        self.create_connections()

    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle(self.WINDOW_TITLE)
        self.setGeometry(*self.WINDOW_GEOMETRY)
        self.setStyleSheet("background-color: white;")

        self.create_widgets()
        self.setup_layout()

    def create_widgets(self):
        """
        初始化并配置界面控件

        创建组合框、开始按钮和单选框控件，并使用预定义的选项数据初始化下拉框。
        控件直接挂载到父窗口，通过类成员变量保存控件引用。
        """
        self.label_game = QLabel('选择游戏:', self)
        self.combobox_game = QComboBox()
        self.combobox_game.addItems(['星穹铁道', '绝区零'])

        self.label_function = QLabel('选择功能:', self)
        self.combobox_function = QComboBox()

        self.radio_weekly = QRadioButton('周本', self)
        self.radio_weekly.setChecked(False)

        self.btn_start = QPushButton('开始', self)
        self.btn_start.setStyleSheet("background-color: gray; color: white;")

    def setup_layout(self):
        """设置界面布局"""
        layout = QVBoxLayout()
        layout.addWidget(self.label_game)
        layout.addWidget(self.combobox_game)
        layout.addWidget(self.label_function)
        layout.addWidget(self.combobox_function)
        layout.addWidget(self.radio_weekly)
        layout.addWidget(self.btn_start)
        self.setLayout(layout)

    def create_connections(self):
        """建立信号槽连接"""
        self.btn_start.clicked.connect(self.on_start_clicked)
        self.combobox_game.currentIndexChanged.connect(self.on_game_selected)
        self.radio_weekly.toggled.connect(self.on_weekly_radio_changed)

    def on_game_selected(self, index):
        """游戏选择事件处理"""
        self.game = self.combobox_game.currentText()
        self.combobox_function.clear()
        if self.game == '星穹铁道':
            self.combobox_function.addItems(['遗器', '位面', '养成'])
        elif self.game == '绝区零':
            self.combobox_function.addItems(['养成', '每日'])

    def on_weekly_radio_changed(self, state):
        """单选框状态改变事件处理"""
        self.state = state
        print(f"周本状态：{'已选中' if self.state else '未选中'}")

    def on_start_clicked(self):
        """开始按钮点击事件处理"""
        if self.game == '星穹铁道':
            selected_data = self.combobox_function.currentText()
            if selected_data == '遗器':
                SR_new.SR_start('yiqi', self.state)
            elif selected_data == '位面':
                SR_new.SR_start('weimian', self.state)
            elif selected_data == '养成':
                SR_new.SR_start('peiyan', self.state)
        elif self.game == '绝区零':
            # 这里先空着，后续实现
            pass

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())