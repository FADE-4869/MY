# -*- coding: utf-8 -*-
import pydirectinput as pdi
import win32gui
import win32con
import time
import random


class GameController:
    def __init__(self, game_window_title="崩坏：星穹铁道"):
        self.game_hwnd = self._get_game_window(game_window_title)
        if self.game_hwnd is None:
            raise Exception(f"未找到窗口: {game_window_title}")
        self._init_config()

    def _init_config(self):
        """初始化性能参数 [6,8](@ref)"""
        pdi.PAUSE = 0.001  # 比默认值快100倍
        pdi.FAILSAFE = False  # 禁用安全退出检测

    def _get_game_window(self, title_keyword):
        """获取游戏窗口句柄 [8](@ref)"""

        def callback(hwnd, hwnds):
            if win32gui.IsWindowVisible(hwnd) and title_keyword in win32gui.GetWindowText(hwnd):
                hwnds.append(hwnd)
            return True

        hwnds = []
        win32gui.EnumWindows(callback, hwnds)
        return hwnds[0] if hwnds else None

    def _activate_window(self):
        """强制激活游戏窗口 [6,8](@ref)"""
        try:
            win32gui.ShowWindow(self.game_hwnd, win32con.SW_RESTORE)
            win32gui.SetForegroundWindow(self.game_hwnd)
            time.sleep(0.5)  # 等待窗口切换
        except Exception as e:
            print(f"窗口激活失败: {str(e)}")
            raise

    def human_like_move(self, dx, dy, duration=0.5, step_base=10):
        """拟人化鼠标移动 [6,7](@ref)"""
        steps = max(abs(dx) // step_base, abs(dy) // step_base, 1)  # 动态调整步长基数
        for _ in range(steps):
            px = dx / steps + random.uniform(-5, 5)
            py = dy / steps + random.uniform(-5, 5)
            pdi.moveRel(
                int(px),
                int(py),
                duration=random.uniform(0.01, 0.02)
            )

    def _camera_move(self, x_offset, y_offset):
        """镜头移动逻辑"""
        pdi.mouseDown(button='right')
        self.human_like_move(x_offset, y_offset)
        pdi.mouseUp(button='right')

    def camera_control(self, x_offset, y_offset):
        """镜头控制核心逻辑 [6,8](@ref)"""
        try:
            self._activate_window()

            # 镜头水平转动
            self._camera_move(x_offset, 0)

            # 镜头垂直转动
            time.sleep(random.uniform(0.1, 0.2))  # 减少随机延迟
            self._camera_move(0, y_offset)

        except pdi.PyDirectInputException as e:
            print(f"输入控制异常: {str(e)}")


if __name__ == "__main__":
    controller = GameController("崩坏：星穹铁道")
    time.sleep(2)
    pdi.keyDown('altleft')  # 按下左 Alt
    time.sleep(2)
    # 示例：向右转动100像素，向上50像素
    controller.camera_control(2000, 100)

    # # 模拟W键前进（带随机延迟）
    # pdi.keyDown('w')
    # time.sleep(2 + random.uniform(-0.2, 0.2))
    # pdi.keyUp('w')
