import time
import Getposition
import pyautogui
import win32gui
# 根据类名获取句柄（适合已知类名的标准应用）
# 正确写法
def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.85)
    return up_left
def Chat():
    z = 0
    while z < 3:
        try:
            if Getposition.get_position('zhinan') is not None:
                pyautogui.moveTo(Getposition.get_position('zhinan'))
                pyautogui.click()
                time.sleep(1.5)
                pyautogui.moveTo(362, 213)
                pyautogui.click()
                break
        except pyautogui.ImageNotFoundException:
            pyautogui.press('esc')
            print("未找到指南。。。。")
            time.sleep(1)
            z = z + 1

    time.sleep(1)
    pyautogui.hotkey('ctrl', 'w')  # 使用 hotkey 方法发送组合键
    while True:
        try:
            if get_position('11') is not None:
                pyautogui.click(get_position('11'))

                break
        except pyautogui.ImageNotFoundException:
            print('未找到looking')


    while True:
        try:
            if get_position('cut') is not None:
                pyautogui.moveTo(get_position('cut'))
                time.sleep(0.5)
                pyautogui.doubleClick()
                time.sleep(1)
                break
        except pyautogui.ImageNotFoundException:
            print('未找到剪切')
    pyautogui.click()
    time.sleep(1.2)
    pyautogui.click()
    while True:
        try:
            if get_position('gou') is not None:
                pyautogui.moveTo(get_position('gou'))
                time.sleep(0.5)
                pyautogui.doubleClick()
                time.sleep(1)
                break
        except pyautogui.ImageNotFoundException:
            print('未找到勾')

    while True:
        try:
            if get_position('S') is not None:
                pyautogui.moveTo(get_position('S'))
                time.sleep(0.5)
                pyautogui.doubleClick()
                time.sleep(2.5)
                break
        except pyautogui.ImageNotFoundException:
            print('未找到发送')


    pyautogui.hotkey('ctrl', 'w')



if __name__ == '__main__':
    Chat()