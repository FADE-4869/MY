import time
import pyautogui
import threading
from pynput.keyboard import Controller, Key
import ZZZGetposition
from PIL import ImageGrab
import coloer
# 初始化全局控制变量
running = True
x = 0  # 初始化全局变量
keyboard = Controller()

global_x = 1670  # 区域横向中心
global_y = 990
# def hex_to_rgb(hex_color):
#     hex_color = hex_color.lstrip("#")
#     return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def hex_to_grayscale(hex_color):
    r, g, b = hex_color
    return (r + g + b) // 3  # 简单平均值
def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{}.png'.format(word),confidence=0.95,region=(1616,913,101,104))
    return up_left
def image_detector():
    while True:
        try:

            if ZZZGetposition.get_position('ya') is not None:

                print('找到ya')
                break
            else:
                print('未找到ya')
                hold_key(Key.space, 0.2)
        except pyautogui.ImageNotFoundException:
            hold_key(Key.space, 0.2)
            time.sleep(0.5)

def hold_key(key, duration):
    keyboard.press(key)
    time.sleep(duration)
    keyboard.release(key)
def key_operations():

    while True:
        try:
            if ZZZGetposition.get_position('ZZ') is not None:
                time.sleep(3)
                hold_key('s', 1.2)
                time.sleep(1)
                hold_key('e', 0.4)
                time.sleep(0.5)
                image_detector()
                break
        except pyautogui.ImageNotFoundException:
            print('未找到')
            time.sleep(0.5)

    while True:

        if 125 < hex_to_grayscale(coloer.get_color_at_position(global_x, global_y)) < 135:
            print('找到e')
            image_detector()
            hold_key('e', 0.5)
            time.sleep(1)
            hold_key('q', 0.5)
            time.sleep(1)
            image_detector()
            hold_key('j', 0.5)
            time.sleep(1.893)
            hold_key('j', 0.5)
            time.sleep(1.893)
            # hold_key('j', 0.5)
            # time.sleep(1.893)
        else:
            print('未找到e')
        t=0
        while t<25:
            image_detector()
            hold_key('j', 0.2)
            time.sleep(0.3)
            print("j攻击")
            t=t+1


# def key_E():
#     # while True:
#             # try:jjjjjjjjjjjj
#             #     if ZZZGetposition.get_position('ZZ') is not None:
#             #         print('找到zz')
#             #         break
#             # except pyautogui.ImageNotFoundException:
#             #     print('未找到zz')jjjjej

def main():
    detector_pugong = threading.Thread(target=key_operations)
    detector_pugong.daemon=True
    # detector_E = threading.Thread(target=key_E)
    # detector_E.daemon = True


    try:
        # 启动检测线程和操作线程
        detector_pugong.start()
        # detector_E.start()
        print('[系统] 所有线程已启动，按CTRL+C停止')

        # 保持主线程存活（空转防止程序退出）
        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        # 捕获中断信号后执行线程安全退出流程
       # 设置全局运行标志为False
        print('[系统] 正在停止所有线程...')

        # 等待线程结束（设置超时防止永久阻塞）
        detector_pugong.join(timeout=1)
        # detector_E.join(timeout=1)
        print('[系统] 已安全退出')


if __name__ == '__main__':
    main()