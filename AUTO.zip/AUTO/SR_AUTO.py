import threading
import pyautogui
import time
import SR_coloer


def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.80,region=(0, 930, 115, 78))
    return up_left

def SR_coloer_db(some_condition):

    def SR_AUTO_COLOR():
        if not some_condition:
            print("SR_AUTO.COLOR() is not running")
            return


        NUM = 0

        time.sleep(1)
        while NUM < 25:
            try:
                if get_position('Z') is not None :
                    time.sleep(1)
                    print("找到1")
                    try:
                        if  get_position('Z')is not None:
                            time.sleep(1)
                            print("找到2")
                            time.sleep(1)
                            pyautogui.press('v')
                            print('图片2 "V" 已找到并点击')
                            break

                    except pyautogui.ImageNotFoundException:

                        print('1未找到Z')
                        time.sleep(0.5)
            except pyautogui.ImageNotFoundException:
                    NUM = NUM + 1
                    print('未找到Z')
                    time.sleep(0.5)
        print('开始')
        print("SR_AUTO.COLOR() is running")

    # 启动线程
    if some_condition:
        color_thread = threading.Thread(target=SR_AUTO_COLOR)
        color_thread.start()
    else:
        print("SR_AUTO.COLOR() is not running")

if __name__ == "__main__":
    SR_coloer_db(True)
