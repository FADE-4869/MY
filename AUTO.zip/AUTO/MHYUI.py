import sys
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout,
                             QPushButton, QComboBox)
import SR_account


class MainWindow(QWidget):
    WINDOW_TITLE = 'PyQt5基础框架'
    WINDOW_GEOMETRY = (300, 300, 300, 200)
    COMBO_OPTIONS = [
        ('遗器', 'yiqi'),
        ('养成', 'peiyan'),
        ('面位饰品', 'weimian')
    ]

    def __init__(self):
        super().__init__()
        self.init_ui()
        self.create_connections()

    def init_ui(self):
        """初始化用户界面"""
        self.setWindowTitle(self.WINDOW_TITLE)
        self.setGeometry(*self.WINDOW_GEOMETRY)

        self.create_widgets()
        self.setup_layout()

    def create_widgets(self):
        """
        初始化并配置界面控件

        创建组合框和开始按钮控件，并使用预定义的选项数据初始化下拉框。
        控件直接挂载到父窗口，通过类成员变量保存控件引用。
        """
        self.combobox = QComboBox()
        self.btn_start = QPushButton('开始', self)

        # 使用COMBO_OPTIONS元组数据初始化下拉框选项
        # 每个选项包含显示文本(display_text)和关联数据(user_data)
        for display_text, user_data in self.COMBO_OPTIONS:
            self.combobox.addItem(display_text, user_data)

    def setup_layout(self):
        """设置界面布局"""
        layout = QVBoxLayout()
        layout.addWidget(self.combobox)
        layout.addWidget(self.btn_start)
        self.setLayout(layout)

    def create_connections(self):
        """建立信号槽连接"""
        self.btn_start.clicked.connect(self.on_start_clicked)
        self.combobox.currentIndexChanged.connect(self.on_combobox_selected)

    def on_start_clicked(self):
        """开始按钮点击事件处理"""
        # 获取实际存储的数据而非显示文本
        selected_data = self.combobox.currentData()
        self.start_processing(selected_data)

    def on_combobox_selected(self, index):
        """下拉菜单选择事件处理"""
        selected_text = self.combobox.itemText(index)
        print(f"当前选择：{selected_text}")
        self.handle_combobox_selection(index)

    def start_processing(self, selected_option):
        """业务逻辑处理函数"""
        print(f"开始处理选择的选项：{selected_option}")
        try:
            SR_new.SR_start(selected_option)
        except Exception as e:
            print(f"处理过程中发生错误：{str(e)}")
            # 实际项目中可添加错误弹窗等处理

    def handle_combobox_selection(self, index):
        """下拉菜单选择处理函数"""
        # 保留扩展功能接口
        pass


if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())
