import sys
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QComboBox,
                             QPushButton, QCheckBox, QLabel)
from PyQt5.QtGui import QColor, QLinearGradient, QPalette, QFont

import SR_account


class GameUI(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.setupConnections()

    def initUI(self):
        self.setWindowTitle('Game Tools')
        self.setGeometry(300, 300, 300, 200)

        # 设置背景渐变
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(240, 240, 240))  # 浅灰色
        gradient.setColorAt(1, QColor(200, 200, 200))  # 深灰色
        palette = self.palette()
        palette.setBrush(QPalette.Window, gradient)
        self.setPalette(palette)

        # 布局
        layout = QVBoxLayout()
        layout.setSpacing(15)  # 增加控件间距

        # 游戏选择
        self.game_label = QLabel("选择游戏:")
        self.game_label.setFont(QFont("Arial", 12, QFont.Bold))
        self.game_combo = QComboBox()
        self.game_combo.addItems(["星穹铁道", "绝区零"])
        self.setComboBoxStyle(self.game_combo)

        # 功能选择
        self.feature_label = QLabel("选择功能:")
        self.feature_label.setFont(QFont("Arial", 12, QFont.Bold))
        self.feature_combo = QComboBox()
        self.setComboBoxStyle(self.feature_combo)

        # 单选框
        self.checkbox = QCheckBox("启用状态")
        self.checkbox.setFont(QFont("Arial", 12))
        self.checkbox.setStyleSheet("""
            QCheckBox::indicator {
                width: 15px;
                height: 15px;
            }
        """)

        # 开始按钮
        self.start_btn = QPushButton("开始执行")
        self.start_btn.setFont(QFont("Arial", 12, QFont.Bold))
        self.start_btn.setStyleSheet("""
            QPushButton {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #4CAF50, stop:1 #45a049);
                color: white;
                border: none;
                padding: 10px;
                border-radius: 5px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #45a049, stop:1 #4CAF50);
            }
        """)

        # 添加控件到布局
        layout.addWidget(self.game_label)
        layout.addWidget(self.game_combo)
        layout.addWidget(self.feature_label)
        layout.addWidget(self.feature_combo)
        layout.addWidget(self.checkbox)
        layout.addWidget(self.start_btn)
        layout.addStretch()

        self.setLayout(layout)
        self.updateFeatureOptions()

    def setComboBoxStyle(self, combo_box):
        """设置 ComboBox 的样式"""
        combo_box.setStyleSheet("""
            QComboBox {
                background-color: #F0F0F0;
                border: 1px solid #808080;
                padding: 5px;
                border-radius: 3px;
                font-size: 12px;
            }
            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 15px;
                border-left-width: 1px;
                border-left-color: darkgray;
                border-left-style: solid;
                border-top-right-radius: 3px;
                border-bottom-right-radius: 3px;
            }
        """)

    def setupConnections(self):
        self.game_combo.currentIndexChanged.connect(self.updateFeatureOptions)
        self.start_btn.clicked.connect(self.executeTask)

    def updateFeatureOptions(self):
        game = self.game_combo.currentText()
        self.feature_combo.clear()

        if game == "星穹铁道":
            self.feature_combo.addItems(["遗器", "位面", "养成"])
        elif game == "绝区零":
            self.feature_combo.addItems(["养成", "每日"])

    def executeTask(self):
        game = self.game_combo.currentText()
        feature = self.feature_combo.currentText()
        state = self.checkbox.isChecked()

        if game == "星穹铁道":
            feature_map = {
                "遗器": "yiqi",
                "位面": "weimian",
                "养成": "yangcheng"
            }
            if feature in feature_map:
                self.starrail_function(feature_map[feature], state)
            else:
                print(f"未知的功能选项：{feature}")
        else:
            self.zenless_function(feature)

    def starrail_function(self, feature: str, state: bool):
        """星穹铁道功能函数"""
        print(f"执行星穹铁道功能：{feature}，状态：{state}")
        try:
            SR_new.SR_start(feature, state)
        except Exception as e:
            print(f"处理过程中发生错误：{str(e)}")

    def zenless_function(self, feature: str):
        """绝区零功能函数"""
        print(f"执行绝区零功能：{feature}")
        # 在这里实现具体功能


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = GameUI()
    ex.show()
    sys.exit(app.exec_())
