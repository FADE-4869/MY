import time
import pyautogui
import keyboard
from threading import Thread, Lock
import ZZZ_coloer
from ZZZ_coloer import get_color_at_position

# 全局控制变量
is_running = False
PAUSE_KEY = 'u'
# 线程锁
is_running_lock = Lock()

def get_position(word, confidence=0.9, region=(1357, 584, 205, 205), max_retries=10):
    up_left = None
    retries = 0
    while up_left is None and retries < max_retries:
        up_left = pyautogui.locateCenterOnScreen(f'C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{word}.png',
                                                 confidence=confidence, region=region)
        retries += 1
        time.sleep(0.1)
    return up_left

def set_running_state(state):
    """设置 is_running 的状态，确保线程安全"""
    global is_running
    with is_running_lock:
        is_running = state

def get_running_state():
    """获取 is_running 的状态，确保线程安全"""
    global is_running
    with is_running_lock:
        return is_running

def toggle_pause():
    """切换暂停状态"""
    while True:
        try:
            if get_color_at_position(405, 846) == (20, 20, 20):
                set_running_state(not get_running_state())
                state = "继续" if get_running_state() else "暂停"
                print(f"程序已 {state}")
                time.sleep(0.1)
        except Exception as e:
            print(f'发生异常: {e}')
            set_running_state(False)
            time.sleep(1)

# 注册热键回调
keyboard.add_hotkey(PAUSE_KEY, toggle_pause)

def main_loop():
    time.sleep(3)
    print(f"程序启动，按 {PAUSE_KEY} 切换暂停/继续")

    while True:
        try:
            if get_position('Tou') is not None:
                print('找到Tou')
                pyautogui.doubleClick(get_position('Tou'))
        except pyautogui.ImageNotFoundException:
            print('未找到Tou')

        if get_running_state():
            keyboard.press('space')
            print("space")
            time.sleep(0.1)
        else:
            time.sleep(0.05)

if __name__ == "__main__":
    main_loop()
