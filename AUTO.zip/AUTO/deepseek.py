import ollama
print(ollama.list())
while True:
    # 获取用户输入的问题
    user_input = input("请输入你的问题（输入'退出'以结束对话）：")

    # 如果用户输入'退出'，则结束循环
    if user_input.lower() == '退出':
        print("对话结束。")
        break
    
    # 使用ollama生成回答
    response = ollama.generate(
        model="deepseek-r1:14b",
        prompt=user_input,
        options={  # 所有模型参数需在此字典中设置
            "temperature": 0.9,  # 控制随机性
            "num_predict": 100,  # 限制输出长度
            "top_p": 0.9         # 控制采样范围
        },
        stream=False
    )
    
    # 打印模型的回答
    print("回答：", response["response"])