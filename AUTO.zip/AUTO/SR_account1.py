import time#pythonproject
import pytesseract
import cv2
import re

import SR_Year
import SR_jinru
import SR_jinru1
import SRday
import SRweituo
import SRwuming
import SRqianzhen
import pyautogui
import SR_account2
from pynput.keyboard import Controller
import SRswich2
import SR_YueKa

def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.85)
    return up_left

def hold_key(key, duration):
    keyboard = Controller()
    keyboard.press(key)
    time.sleep(duration)
    keyboard.release(key)


djiR=False
def SR_USERbku(state):
    # word2="yiqi"
    # global djiR
    # SRswich2.SR_switch('bq708599', '19271687855')
    # djSR=True
    # SR_YueKa.YueKa(djSR)
    #
    # while True:
    #     try:
    #         if get_position('rwl') is not None:
    #             print('已经找到任务栏')
    #
    #             break
    #     except pyautogui.ImageNotFoundException:
    #         pyautogui.press('F4')
    #         print('未找到任务栏')
    #         time.sleep(2)
    #
    # time.sleep(1)
    # num = 0
    # while True:
    #     try:
    #         if get_position('moni') is not None:
    #             pyautogui.moveTo(get_position('moni'))
    #             time.sleep(0.5)
    #             pyautogui.doubleClick()
    #             time.sleep(2)
    #             break
    #
    #
    #     except pyautogui.ImageNotFoundException:
    #
    #         print('未找到模拟宇宙按键1')
    #
    #         break
    #
    # pyautogui.moveTo(1478, 64)
    # pyautogui.click()
    # time.sleep(0.5)
    # pyautogui.moveTo(1674, 67)
    # pyautogui.click()
    # time.sleep(1.5)
    #
    # # 截图并保存
    # screenshot = pyautogui.screenshot(region=(627, 723, 80, 35))  # x, y, width, height
    # screenshot_path = 'C:\\Users\\DELL\\PycharmProjects\\AUTO\\resource\\screenshot1.png'
    # screenshot.save(screenshot_path)
    #
    # # 读取图像并转换为灰度
    # image = cv2.imread(screenshot_path)
    # gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    #
    # # 自适应直方图均衡化
    # clahe = cv2.createCLAHE(clipLimit=25.0, tileGridSize=(10, 10))
    # enhanced_image = clahe.apply(gray_image)
    #
    # # 使用 pytesseract 识别数字
    # text = pytesseract.image_to_string(enhanced_image, config='--oem 3 --psm 6')
    # numbers = re.findall(r'\b\d+\b', text)
    # print(numbers)
    #
    # pyautogui.moveTo(1673, 309)
    # pyautogui.click()
    # time.sleep(0.5)
    # pyautogui.moveTo(1673, 309)
    # pyautogui.click()
    # time.sleep(0.5)
    #
    # int_num = int(numbers[0])
    #
    # print(f"共有 {int_num}开括力")
    # # print(f"共有 {int_NUM }沉浸器")
    #
    # SR_jinru1.SR_JR(word2, state, int_num)
    # pyautogui.press('esc')
    # time.sleep(5)
    #
    # # ----------------------------------------------------------好友赠礼--------------------------------------------------------------------#
    # SRqianzhen.SRaward()
    # # -------------------------------------------------------------委托------------------------------------------------------------------------------------#
    #
    # SRweituo.SR_weituo()
    #
    # # ----------------------------------------------------无名勋章----------------------------------------------------------#
    #
    # SRwuming.WUMING()
    #
    # # ---------------------------------------------------------------指南--------------------------------------------------------------------
    # SRday.Daily_Reward()
    #
    # # --------------------------------------------------------------------关闭程序----------------------------------------------------------------------#
    # SR_Year.Yearlinqu()
    #

    SR_account2.SR_USERbku(state)
# if __name__ == '__main__':
