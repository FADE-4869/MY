import time

import pyautogui

import NUM_ACR


def Cless(word):

    if word == 'yiqi' or word == 'yangchen':
        pyautogui.moveTo(1478, 64)
        pyautogui.click()
        time.sleep(0.5)
        pyautogui.moveTo(1674, 67)
        pyautogui.click()
        time.sleep(2.5)
        yiqi = 624, 726, 56, 37
        numbers = NUM_ACR.get_Num_ACR(*yiqi)
        print(numbers)
        int_num = int(numbers[0])
        print(f"共有 {int_num}开括力")

        pyautogui.moveTo(1673, 309)
        pyautogui.click()
        time.sleep(0.5)
        pyautogui.moveTo(1673, 309)
        pyautogui.click()
        time.sleep(0.5)


        return numbers
    elif word == 'weimian':
        yiqi2 = 1663, 51, 74, 31
        numbers = NUM_ACR.get_Num_ACR(*yiqi2)
        time.sleep(1)
        print("位面盘=" + str(numbers))
        return numbers