import pyautogui
import time
import keyboard
def SR_rewuXuanZhe(word,x1,y1):
    while True:
        try:
            time.sleep(1)
            # 查找图片位置并获取坐标信息

            location = pyautogui.locateOnScreen(
                'C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                confidence=0.9
            )

            if location is not None:
                print("找到目标图片，坐标：", location)

                # 计算图片中心坐标
                x = location.left + x1
                y = location.top + y1

                # 点击中心位置（可根据需要调整偏移量）
                pyautogui.click(x, y)
                print(f"已点击坐标 ({x}, {y})")
                time.sleep(1)
                break

        except pyautogui.ImageNotFoundException:
            print('未找到模拟宇宙按键1')
            break
