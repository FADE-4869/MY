import time
import pyautogui
import threading
from pynput.keyboard import Controller, Key
import ZZZGetposition

# 常量定义
KEY_E_DELAY = 1.893
IMAGE_PATH = 'C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{}.png'
KEY_CONFIG = {'e': 0.5, 'j': 0.1}

# 线程控制对象
running = threading.Event()
running.set()
exit_event = threading.Event()
lock = threading.Lock()

keyboard = Controller()

def get_position(word: str) -> tuple:
    """带间隔的图片查找函数"""
    while not exit_event.is_set():
        try:
            if pos := pyautogui.locateCenterOnScreen(
                IMAGE_PATH.format(word),
                confidence=0.85
            ):
                return pos
            time.sleep(0.2)  # 降低重试频率
        except pyautogui.ImageNotFoundException:
            time.sleep(0.1)

def hold_key(key: str, duration: float):
    """封装基础按键操作"""
    with lock:
        keyboard.press(key)
        time.sleep(duration)
        keyboard.release(key)

def perform_sequence(sequence: list):
    """执行预定义操作序列"""
    for key, delay in sequence:
        hold_key(key, KEY_CONFIG.get(key, 0.1))
        time.sleep(delay)

def key_operations():
    """E键检测线程"""
    sequence_e = [('e', 1), ('j', 1.893)] * 3
    while not exit_event.is_set():
        try:
            if get_position('E'):
                print('找到e')
                running.clear()  # 暂停其他线程
                perform_sequence(sequence_e)
                running.set()
        except Exception as e:
            print(f'key_operations error: {str(e)}')
            exit_event.set()
        time.sleep(0.1)  # 降低CPU占用

def key_E():
    """ZZ键检测线程"""
    while not exit_event.is_set():
        try:
            if ZZZGetposition.get_position('ZZ'):
                print('找到zz')
                break
        except Exception as e:
            print(f'key_E error: {str(e)}')
            exit_event.set()
    
    while running.is_set() and not exit_event.is_set():
        hold_key('j', 0.1)
        time.sleep(0.5)

def main():
    threads = []
    try:
        for target in [key_operations, key_E]:
            t = threading.Thread(target=target, daemon=True)
            t.start()
            threads.append(t)
        
        print('[系统] 所有线程已启动，按CTRL+C停止')
        while not exit_event.is_set():
            time.sleep(1)

    except KeyboardInterrupt:
        print('[系统] 正在停止所有线程...')
        exit_event.set()
        
        for t in threads:
            t.join(timeout=2)
        print('[系统] 已安全退出')

if __name__ == '__main__':
    main()
