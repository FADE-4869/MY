import os
import time
import pyautogui
import cv2
import re
import subprocess
import logging
from PIL import Image
import pytesseract
import SRday
import SRweituo
import SRwuming
import SRqianzhen
import Kill_SR
import renwu
def SRAI(word2):
    # 配置常量
    PATH_CONFIG = {
        'SR_IMG_DIR': 'C:/Users/DELL/PycharmProjects/AUTO/resource/SR',
        'SCREENSHOT_DIR': 'C:/Users/DELL/PycharmProjects/AUTO/resource',
        'GAME_EXE': r"D:\miHoYo Launcher\games\Star Rail Game\StarRail.exe"
    }
    SCREEN_REGIONS = {
        'power': (1468, 51, 100, 34),
        'immersifier': (1674, 51, 66, 34),
        'stamina': (1338, 52, 77, 27)
    }
    COORDINATES = {
        'cultivate': (407, 353),
        'max_btn': (1740, 899),
        'challenge': (1617, 989)
    }
    MAX_RETRIES = 10

    # 初始化日志
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s: %(message)s')

    def safe_ocr_extract(image_path, pattern):
        """安全的OCR数字提取"""
        image = cv2.imread(image_path)
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        text = pytesseract.image_to_string(gray_image, config='--oem 3 --psm 6')
        numbers = re.findall(r'\b\d+\b', text)
        return int(numbers[0]) if numbers else 0

    def get_position_with_retry(image_name, max_attempts=10):
        """带重试机制的图像定位"""
        for _ in range(max_attempts):
            try:
                pos = pyautogui.locateCenterOnScreen(
                    os.path.join(PATH_CONFIG['SR_IMG_DIR'], f'{image_name}.png'),
                    confidence=0.85
                )
                if pos: return pos
            except pyautogui.ImageNotFoundException:
                time.sleep(1)
        raise Exception(f"Max attempts reached for locating {image_name}")

    def game_login_flow():
        """封装登录流程"""
        pyautogui.FAILSAFE = False
        subprocess.Popen(PATH_CONFIG['GAME_EXE'])

        for _ in range(MAX_RETRIES):
            try:
                if pyautogui.locateOnScreen(os.path.join(PATH_CONFIG['SR_IMG_DIR'], 'using.png'), confidence=0.9):
                    pyautogui.click(get_position_with_retry('using'))
                    pyautogui.click(get_position_with_retry('password'))
                    pyautogui.write(os.getenv('GAME_PASSWORD'))  # 从环境变量获取
                    pyautogui.click(get_position_with_retry('phone'))
                    pyautogui.write(os.getenv('PHONE_NUMBER'))   # 从环境变量获取
                    pyautogui.click(get_position_with_retry('00'))
                    pyautogui.click(get_position_with_retry('SRstart'))
                    return
            except pyautogui.ImageNotFoundException:
                time.sleep(2)

    def process_game_resources():
        """处理游戏资源识别"""
        resource_data = {}
        for key, region in SCREEN_REGIONS.items():
            path = os.path.join(PATH_CONFIG['SCREENSHOT_DIR'], f'{key}.png')
            pyautogui.screenshot(region=region).save(path)
            resource_data[key] = safe_ocr_extract(path, r'\b\d+\b')

        target_finds = resource_data['power'] // 40
        total_clicks = target_finds + resource_data['immersifier'] - 1
        logging.info(f"资源状态: 开括力={resource_data['power']}, 沉浸器={resource_data['immersifier']}, 额外={resource_data['stamina']}")
        return total_clicks

    def combat_loop(total_clicks):
        """战斗循环逻辑优化"""
        # 简化的战斗操作逻辑
        pyautogui.click(*COORDINATES['cultivate'])
        renwu.SR_rewuXuanZhe(word2)
        pyautogui.click(*COORDINATES['max_btn'])
        pyautogui.doubleClick(*COORDINATES['challenge'])

        # 简化后的战斗流程
        for _ in range(total_clicks):
            get_position_with_retry('again')
            pyautogui.click()
            time.sleep(2)

    def SR_start(word2):
        """重构后的主流程"""
        logging.info(f"启动任务: {word2}")
        game_login_flow()

        # 月卡处理
        for _ in range(8):
            try:
                if get_position_with_retry('yueka', max_attempts=1):
                    pyautogui.click()
                    pyautogui.moveRel(200, 0, duration=1)
                    [pyautogui.click() for _ in range(2)]
                    break
            except Exception:
                time.sleep(1)

        # 任务处理
        get_position_with_retry('rwl', max_attempts=10)

        # 资源处理
        total_clicks = process_game_resources()
        if total_clicks > 0:
            combat_loop(total_clicks)

        # 收尾操作
        pyautogui.press('esc')
        SRqianzhen.SRaward()
        SRweituo.SR_weituo()
        SRwuming.WUMING()
        SRday.Daily_Reward()
        Kill_SR.kill_process_by_name('StarRail')

    # if __name__ == "__main__":
    #     SR_start("默认任务")
