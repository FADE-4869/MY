

from pynput.keyboard import Controller

from pynput.keyboard import Key


import pydirectinput
import time#pythonproject
import pyautogui

import ZZZKO

from ZZZGetposition import get_position

def get_position1(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{}.png'.format(word),
                                                 confidence=0.9,region=(1755, 686, 121, 362))
    return up_left
def get_position2(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{}.png'.format(word),
                                                 confidence=0.9,region=(681, 759, 543, 116))
    return up_left

def hold_key(key, duration):
    keyboard = Controller()
    keyboard.press(key)
    time.sleep(duration)
    keyboard.release(key)

def SR_switch(password,user):
    num1 = 0
    while True:
        try:
            if get_position('ZZZ_Q')is not None:
                pyautogui.click(get_position('ZZZ_Q'))
                time.sleep(0.5)
                pyautogui.click(get_position('denchu'))
                break

        except pyautogui.ImageNotFoundException:
            hold_key(Key.esc, 0.4)
            print('未找到Q')
            time.sleep(1.5)
            num1+=1
    ZZZKO.queding()
    num = 0
    while num < 15:
        try:

              if get_position1('ZZZdjjr')is not None:
                time.sleep(0.5)
                pyautogui.click(get_position1('swich'))
                time.sleep(0.5)
                pyautogui.click(1136, 776)  # 确定
                print("点击确定")
                break


        except pyautogui.ImageNotFoundException:
            time.sleep(1)
            num+=1
            print('未能登出')
            time.sleep(0.5)




    num = 0

    while num < 60:
        try:
            if  get_position2('using')is not None:
                time.sleep(0.5)
                pyautogui.moveTo(get_position('using'))
                time.sleep(1.5)
                pyautogui.click(858,810)
                time.sleep(0.7)
                pyautogui.click(get_position('password'))
                time.sleep(0.7)
                pyautogui.write(password)
                time.sleep(0.7)
                pyautogui.click(get_position('phone'))
                time.sleep(0.7)
                pyautogui.write(user)
                time.sleep(0.7)
                pyautogui.click(622, 559)
                time.sleep(0.5)
                pyautogui.click(623, 627)
                time.sleep(0.5)
                pyautogui.click(get_position('ZZZstart'))


                # pyautogui.moveTo(952, 495)
                # pydirectinput.click(952, 495)  # 点击下拉框
                # print("queding")
                #
                # pyautogui.click(get_position4('user1'))
                # time.sleep(1)
                # pyautogui.click(960, 635)
                break


        except pyautogui.ImageNotFoundException:
            time.sleep(1)
            num = num + 1
            print('未找到用户')


    time.sleep(1)
    print("切换")



    time.sleep(1)
    pyautogui.click(960,635)
    pydirectinput.click(952, 495)
    while True:
        try:
            if get_position1('ZZZdjjr') is not None:
                print('已经找到图片')
                pyautogui.click()

                break
        except pyautogui.ImageNotFoundException:

            print('未找到点击开始')

            time.sleep(0.1)

if __name__ == '__main__':
    SR_switch('123456kzy','18771916560')
    # ZZZtest2.main()
    # ZZZV5.main()
