import threading
import time

# 全局信号量对象，初始值为1
semaphore = threading.Semaphore(1)

def worker(name):
    print(f"[{name}] 等待获取信号量...")
    semaphore.acquire()  # P操作
    print(f"[{name}] 获取信号量，开始工作！")
    time.sleep(2)  # 模拟工作
    print(f"[{name}] 工作完成，释放信号量！")
    semaphore.release()  # V操作

if __name__ == "__main__":
    threads = []
    for i in range(3):
        t = threading.Thread(target=worker, args=(f"线程{i+1}",))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()