import logging
import threading

import SRKO
import pydirectinput
import time#pythonproject
import pyautogui

from Getposition import get_position


def get_positionX(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.90)
    return up_left

def get_position1(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.80,region= (1845,954,50,50))
    return up_left

def get_position2(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.85,region= (1783,240,88,88))
    return up_left
def get_position3(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.90,region= (685,545,228,383))
    return up_left

def SR_switch(password,user):
    num1 = 0
    while num1 < 5:
        try:
            if get_position1('Q')is not None:
                pyautogui.click(get_position1('Q'))
                time.sleep(0.5)
                break

        except pyautogui.ImageNotFoundException:
            pyautogui.press('esc')
            print('未找到Q')
            time.sleep(1.5)
            num1+=1
    SRKO.queding()
    num = 0
    while num < 10:
        try:
            if get_position2('dengchu')is not None:
                pyautogui.click(get_position2('dengchu'))
                time.sleep(1)
                pyautogui.click(1087,688)
                time.sleep(2)

                break

        except pyautogui.ImageNotFoundException:
            time.sleep(1)
            num+=1
            print('未能登出')
            time.sleep(0.5)

    num = 0

    while num < 60:
        try:
            if get_positionX('using') is not None:
                pyautogui.click(958, 704)
                time.sleep(0.5)
                pyautogui.moveTo(get_positionX('using'))
                pyautogui.click()
                time.sleep(0.5)
                pyautogui.click(695, 571)
                time.sleep(0.5)
                pyautogui.moveTo(get_positionX('password'))
                pyautogui.click()
                pyautogui.write(password)
                time.sleep(0.5)
                pyautogui.moveTo(get_positionX('phone'))
                time.sleep(0.5)
                pyautogui.doubleClick()
                pyautogui.write(user)
                time.sleep(0.4)
                pyautogui.moveTo(695, 606)
                pyautogui.click()
                time.sleep(0.5)
                pyautogui.moveTo(get_positionX('SRstart'))
                pyautogui.click()

                # pyautogui.moveTo(952, 495)
                # pydirectinput.click(952, 495)  # 点击下拉框
                # print("queding")
                #
                # pyautogui.click(get_position4('user1'))
                # time.sleep(1)
                # pyautogui.click(960, 635)
                break


        except pyautogui.ImageNotFoundException:
            time.sleep(1)
            num = num + 1
            print('未找到用户')
            time.sleep(1)
            print("Imag not found ovn the screen. (Caught ImageNotFoundException)")
    num2=0
    while num2<6:
        try:
            if get_positionX('TY') is not None:
                pyautogui.click(get_positionX('TY'))
                pyautogui.click()
                break

        except pyautogui.ImageNotFoundException:
            num2+=1
    time.sleep(1)
    print("切换")



    while True:
        try:
            if get_positionX('KSYX') is not None:
                print('已经找到图片')
                pyautogui.moveTo(get_positionX('KSYX'))
                pyautogui.click()

                break
        except pyautogui.ImageNotFoundException:

            print('未找到开始游戏')

            time.sleep(0.1)


    while True:
        try:
            if get_positionX('djjr') is not None:
                print('已经找到图片')
                pyautogui.click()

                break
        except pyautogui.ImageNotFoundException:

            print('未找到点击开始')

            time.sleep(0.1)

if __name__ == '__main__':
    SR_switch('bq708599','19271687855')

