import ZZZKO
import time
import pyautogui
from pynput.keyboard import Controller, Key
import ZZZGetposition
import coloer
import ZZZGetpositionfish
import threading
import Kill_SR

# 初始化全局控制变量
running = False

def hold_key(key, duration):
    keyboard = Controller()
    keyboard.press(key)
    time.sleep(duration)
    keyboard.release(key)

def hex_to_grayscale(hex_color):
    r, g, b = hex_color
    return (r + g + b) // 3  # 简单平均值

def image_detector_Ya():
    while True:
        try:
            if ZZZGetposition.get_position('ya') is not None:
                print('找到ya')
                break
            else:
                print('未找到ya')
                hold_key(Key.space, 0.4)
        except pyautogui.ImageNotFoundException:
            hold_key(Key.space, 0.2)
            time.sleep(0.5)

def get_position_nonblock(word):
    """非阻塞式获取图片位置"""
    try:
        return pyautogui.locateCenterOnScreen(
            f'C:/Users/DELL/PycharmProjects/AUTO/resource/ZZZ/{word}.png',
            confidence=0.85
        )
    except pyautogui.ImageNotFoundException:
        return None

def image_detector():
    """独立线程：持续检测游戏画面中的按钮"""
    global running
    a = 0
    while a < 2:  # 修改为检测两次后停止
        again_pos = get_position_nonblock('again')
        if again_pos:
            pyautogui.click(again_pos)
            a += 1
            print(f'[系统] 检测到再来一次按钮，当前次数：{a}')

        queding_pos = get_position_nonblock('queding')
        if queding_pos:
            pyautogui.click(queding_pos)
            print('[系统] 检测到确定按钮')

        time.sleep(0.3)  # 降低CPU占用

    running = False
    print('[系统] 已检测到两次"again"，正在停止所有线程...')

def key_operations():
    global_x = 1670  # 区域横向中心
    global_y = 990
    while True:
        try:
            if ZZZGetposition.get_position('ZZ') is not None:
                time.sleep(0.5)
                hold_key('s', 1.2)
                time.sleep(1)
                hold_key('e', 0.4)
                time.sleep(0.5)
                image_detector_Ya()
                break
        except pyautogui.ImageNotFoundException:
            print('未找到')
            time.sleep(0.5)

    while True:
        if 125 < hex_to_grayscale(coloer.get_color_at_position(global_x, global_y)) < 135:
            print('找到e')
            image_detector_Ya()
            hold_key('e', 0.5)
            time.sleep(1)
            hold_key('q', 0.5)
            time.sleep(1)
            image_detector_Ya()
            hold_key('j', 0.5)
            time.sleep(1.893)
            hold_key('j', 0.5)
            time.sleep(1.893)
        else:
            print('未找到e')
        t = 0
        while t < 18:
            image_detector_Ya()
            hold_key('j', 0.2)
            time.sleep(0.3)
            print("j攻击")
            t = t + 1

def main():
    global running
    running = True
    keyboard = Controller()
    time.sleep(3)
    keyboard.press(Key.f2)
    time.sleep(1.8)
    pyautogui.click(1173, 146)
    time.sleep(1.8)
    pyautogui.click(1474, 437)
    time.sleep(1.8)
    ZZZKO.queding()
    time.sleep(5)
    keyboard.press(Key.esc)
    time.sleep(1.8)
    pyautogui.click(1439, 510)
    time.sleep(1.8)
    pyautogui.click(1290, 825)
    time.sleep(2)
    pyautogui.click(1721, 1027)
    time.sleep(2)
    pyautogui.click(1721, 1027)
    time.sleep(1)

    # 启动检测线程
    detector_thread = threading.Thread(target=image_detector)
    detector_thread.daemon = True  # 设为守护线程

    # 启动操作线程
    operator_thread = threading.Thread(target=key_operations)
    operator_thread.daemon = True

    try:
        detector_thread.start()
        operator_thread.start()
        print('[系统] 所有线程已启动，按CTRL+C停止')

        # 保持主线程运行
        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        running = False
        print('[系统] 正在停止所有线程...')
        detector_thread.join(timeout=1)
        operator_thread.join(timeout=1)
        print('[系统] 已安全退出')

if __name__ == "__main__":
    main()
    print("程序结束")
