import time

import pyautogui

import SR_book

def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.9,region=(1273,434,265,137))
    return up_left

def get_positionYear(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.9,region=(381,946,1285,62))
    return up_left

def Yearlinqu():
    SR_book.SR_book()
    num1=0
    while num1 < 5:
        try:
            if get_position('action') is not None:
                pyautogui.moveTo(get_position('action'))
                pyautogui.click()
                time.sleep(2)
                pyautogui.click(464,152)
                time.sleep(2)
                pyautogui.click(get_positionYear('year'))
                break
        except pyautogui.ImageNotFoundException:

            print('未找到（。。。）')
            time.sleep(1.5)

            num1 = num1 + 1
    SR_book.SR_book()
if __name__ == '__main__':
    Yearlinqu()