# 在函数外部声明全局变量
target_finds = 0
some_condition = 0

def reset_globals():
    """
    重置全局变量 target_finds 和 some_condition 的值为 0
    """
    global target_finds, some_condition
    target_finds =42
    some_condition = 7

# 示例调用
reset_globals()
print(f"target_finds={target_finds}, some_condition={some_condition}")
