
import pyautogui
import pytesseract
import cv2
import re# 将截图保存为临时文件

def get_position_nonblock(position):
    """
    从指定屏幕区域截取图像，识别其中的文本，并提取所有数字。

    参数:
    position (tuple): 屏幕区域的坐标和大小，格式为 (x, y, width, height)。

    返回值:
    list: 从图像中提取的所有数字组成的列表。
    """
    # 截取指定区域的屏幕截图
    screenshot = pyautogui.screenshot(region=position)  # x, y, width, height
    screenshot_path = 'C:\\Users\\DELL\\PycharmProjects\\AUTO\\resource\\screenshot.png'
    screenshot.save(screenshot_path)

    # 读取截图并将其转换为灰度图像
    image = cv2.imread(screenshot_path)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 使用Tesseract OCR引擎识别灰度图像中的文本
    cv2.waitKey(0)
    text = pytesseract.image_to_string(gray_image, config='--oem 3 --psm 6')

    # 从识别的文本中提取所有数字
    numbers = re.findall(r'\b\d+\b', text)
    return numbers

