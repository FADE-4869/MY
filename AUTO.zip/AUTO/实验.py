import pyautogui

from Getposition import get_position

pyautogui.doubleClick(get_position('Tou'))