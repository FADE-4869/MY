import time
import pyautogui
import keyboard
from threading import Thread
import pyautogui
from Getposition import get_position
# 全局控制变量
is_running = True
PAUSE_KEY = 'u'
def get_position2(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.9,region=(251, 41, 40, 40))
    return up_left

def toggle_pause():  # ✅ 正确函数名
    """切换暂停状态"""
    global is_running
    while True:
        try:
            if get_position2('M') is not None:
                print('找到M')
                is_running = True
                state = "继续" if is_running else "暂停"
                print(f"程序已 {state}")
                time.sleep(0.1)
        except pyautogui.ImageNotFoundException:
            print('未找到M')
            is_running = False
            time.sleep(1)






# 注册热键回调（修复函数名）
keyboard.add_hotkey(PAUSE_KEY, toggle_pause)  # ✅ 使用 toggle_pause


def main_loop():
    time.sleep(3)
    print(f"程序启动，按 {PAUSE_KEY} 切换暂停/继续")

    while True:
        try:
            if get_position('Tou') is not None:
                print('找到M')
                pyautogui.doubleClick(get_position('Tou'))
        except pyautogui.ImageNotFoundException:
            print('未找到Tou')

        if is_running:
            pyautogui.press('1')

            pyautogui.press('space')
            time.sleep(0.1)
        else:
            time.sleep(0.05)



if __name__ == "__main__":
    main_loop()