import threading
import time

import pyautogui

from Getposition import get_position


def YueKa_ing():
    num = 0
    time.sleep(4)
    while num <20 :
        try:

            if get_position('yueka') is not None:
                pyautogui.moveTo(get_position('yueka'))
                print('已经找到月卡')
                pyautogui.click()
                pyautogui.moveRel(200, 0, duration=1)
                time.sleep(1)
                pyautogui.click()
                time.sleep(1.5)
                pyautogui.click()
                time.sleep(1.5)
                pyautogui.click()

                break
            else:
                print("Image not found on the screen.月卡")
        except pyautogui.ImageNotFoundException:
            time.sleep(1)
            num = num + 1
            print("未找到月卡Imag not found ovn the screen. (Caught ImageNotFoundException)")

def YueKa(some_value):
    djSR = some_value
    if djSR:
        denlu_thread = threading.Thread(target=YueKa_ing)
        denlu_thread.start()