import Account
import pyautogui
import time
import SR_book
def get_position1(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.9,region=(1260,0,650,439))
    return up_left
def get_position(word):
    up_left = None
    while up_left == None:
        up_left = pyautogui.locateCenterOnScreen('C:/Users/DELL/PycharmProjects/AUTO/resource/SR/{}.png'.format(word),
                                                 confidence=0.9)
    return up_left
def Get_PromoCode():
    SR_book.SR_book()
    num=1
    while num< 4:
        try:
            if get_position1('gift2') is not None:

                pyautogui.moveTo(get_position1('gift2'))
                pyautogui.click()
                time.sleep(1)
                pyautogui.moveTo(get_position1('duihuan'))
                pyautogui.click()
                time.sleep(1)
                pyautogui.click(660,527)
                time.sleep(1)
                pyautogui.write(Account.get_Promo_code(num))
                pyautogui.moveTo(get_position('quedin'))
                pyautogui.click()
                time.sleep(1.5)
                try:
                    if  get_position('duihuan_OK') is not None:
                        pyautogui.moveTo(get_position('quedin'))
                        pyautogui.click()
                        time.sleep(1)
                        num=num+1
                        pyautogui.moveTo(get_position('quedin'))
                        continue
                except pyautogui.ImageNotFoundException:
                        pyautogui.moveTo(get_position('quxiao'))
                        pyautogui.click()
                        num = num + 1
                        continue


        except pyautogui.ImageNotFoundException:
            print('未找到（。。。）')
            time.sleep(1.5)
    num2=0
    while num2<4:
        try:
            if get_position1('gift2') is not None:
                pyautogui.moveTo(1873, 270)
                pyautogui.click()
                time.sleep(1.5)
                pyautogui.click(get_position('Allword'))
                pyautogui.click()
                break
        except pyautogui.ImageNotFoundException:
            pyautogui.press('esc')
            print("未找到指南。。。。")
            time.sleep(1)
            num2=num2+1
    SR_book.SR_book()