import sys

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QPalette, QBrush
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QComboBox,
                             QPushButton, QCheckBox, QLabel, QFileDialog)

import SR_account


class GameUI(QWidget):
    def __init__(self):
        super().__init__()
        self.background_pixmap = None  # 存储原始背景图片
        self.initUI()
        self.setupConnections()

    def initUI(self):
        self.setWindowTitle('Game Tools')
        self.setGeometry(300, 300, 300, 200)
        self.setStyleSheet("background-color: white;")
        # 布局
        layout = QVBoxLayout()
        # 添加背景选择按钮
        self.bg_btn = QPushButton("选择背景图片")
        self.bg_btn.setStyleSheet("""
                    QPushButton {
                        background-color: #A0A0A0;
                        color: white;
                        border: none;
                        padding: 8px;
                        border-radius: 4px;
                        font-size: 14px;
                        margin-bottom: 10px;
                    }
                    QPushButton:hover {
                        background-color: #808080;
                    }
                """)
        # 游戏选择
        self.game_label = QLabel("选择游戏:")
        self.game_combo = QComboBox()
        self.game_combo.addItems(["星穹铁道", "绝区零"])
        self.game_combo.setStyleSheet("""
            QComboBox {
                background-color: #F0F0F0;
                border: 1px solid #808080;
                padding: 5px;
                border-radius: 3px;
            }
        """)

        # 功能选择
        self.feature_label = QLabel("选择功能:")
        self.feature_combo = QComboBox()
        self.feature_combo.setStyleSheet("""
            QComboBox {
                background-color: #F0F0F0;
                border: 1px solid #808080;
                padding: 5px;
                border-radius: 3px;
            }
        """)

        # 单选框
        self.checkbox = QCheckBox("启用状态")
        self.checkbox.setStyleSheet("""
            QCheckBox::indicator {
                width: 15px;
                height: 15px;
            }
        """)

        # 开始按钮
        self.start_btn = QPushButton("开始执行")
        self.start_btn.setStyleSheet("""
            QPushButton {
                background-color: #808080;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #606060;
            }
        """)

        # 添加控件到布局（在最前面添加背景按钮）
        layout.addWidget(self.bg_btn)
        layout.addWidget(self.game_label)
        layout.addWidget(self.game_combo)
        layout.addWidget(self.feature_label)
        layout.addWidget(self.feature_combo)
        layout.addWidget(self.checkbox)
        layout.addWidget(self.start_btn)
        layout.addStretch()

        self.setLayout(layout)
        self.updateFeatureOptions()

    def setupConnections(self):
        self.game_combo.currentIndexChanged.connect(self.updateFeatureOptions)
        self.start_btn.clicked.connect(self.executeTask)

    def selectBackground(self):
        # 打开文件对话框选择图片
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择背景图片", "",
            "图片文件 (*.png *.jpg *.jpeg *.bmp *.gif)"
        )

        if file_path:
            # 加载并存储原始图片
            self.background_pixmap = QPixmap(file_path)
            self.updateBackground()

    def updateBackground(self):
        if self.background_pixmap:
            # 保持宽高比缩放图片到窗口大小
            scaled_pixmap = self.background_pixmap.scaled(
                self.size(),
                Qt.KeepAspectRatioByExpanding,
                Qt.SmoothTransformation
            )

            # 设置背景
            palette = self.palette()
            palette.setBrush(
                QPalette.Window,
                QBrush(scaled_pixmap)
            )
            self.setPalette(palette)
            self.setAutoFillBackground(True)

    def resizeEvent(self, event):
        # 窗口大小改变时更新背景
        self.updateBackground()
        super().resizeEvent(event)

    def updateFeatureOptions(self):
        game = self.game_combo.currentText()
        self.feature_combo.clear()

        if game == "星穹铁道":
            self.feature_combo.addItems(["遗器", "位面", "养成"])
        elif game == "绝区零":
            self.feature_combo.addItems(["养成", "每日"])

    def executeTask(self):
        game = self.game_combo.currentText()
        feature = self.feature_combo.currentText()
        state = self.checkbox.isChecked()

        if game == "星穹铁道":
            # 转换为拼音
            feature_map = {
                "遗器": "yiqi",
                "位面": "weimian",
                "养成": "yangcheng"
            }
            self.starrail_function(feature_map[feature], state)
        else:
            self.zenless_function(feature)

    def starrail_function(self, feature: str, state: bool):
        """星穹铁道功能函数"""
        print(f"执行星穹铁道功能：{feature}，状态：{state}")
        # 在这里实现具体功能
        try:
            SR_new.SR_start(feature, state)
        except Exception as e:
            print(f"处理过程中发生错误：{str(e)}")
    def zenless_function(self, feature: str):
        """绝区零功能函数"""
        print(f"执行绝区零功能：{feature}")
        # 在这里实现具体功能


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = GameUI()
    ex.show()
    sys.exit(app.exec_())
