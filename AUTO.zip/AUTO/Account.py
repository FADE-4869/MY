import pandas as pd
from pathlib import Path

# 使用 pathlib 处理文件路径
file_path = Path(r"C:\\Users\\DELL\\Desktop\\账户.xlsx")

try:
    # 预加载数据
    df = pd.read_excel(file_path)
    df.columns = ['代码号', '名称', '账号', '密码', '时长','内容','任务','兑换码1','兑换码2','兑换码3']
except Exception as e:
    print(f"加载数据失败: {e}")
    df = pd.DataFrame(columns=['代码号', '名称', '账号', '密码', '时长','内容','任务','兑换码1','兑换码2','兑换码3'])

def get_account_info(code, info_type):
    """获取指定代码号的账号或密码"""
    result = df[df['代码号'] == code][info_type]
    return result.values[0] if not result.empty else None

def get_account(code):
    """获取指定代码号的账号"""
    return str(get_account_info(code, '账号'))

def get_password(code):
    """获取指定代码号的密码"""
    return str (get_account_info(code, '密码'))
def get_word(code):
    """获取指定代码号的密码"""
    return str(get_account_info(code, '任务'))

def get_Promo_code(number):
     ressult = df[df['代码号'] ==1]['兑换码'+str(number)]
     return str(ressult.values[0]) if not ressult.empty else None



# 示例用法
print(get_account(12))   # 返回 17673645424
print(get_password(12))  # 返回 faK4241993DK4241993D
print(get_word(12))
print(get_Promo_code(2))