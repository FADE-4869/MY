import pyautogui
import time
import pyautogui
from PIL import Image
import pytesseract
import cv2
import re# 将截图保存为临时文件
import cv2
import pytesseract
import pyautogui
from PIL import Image

# 截图并保存
screenshot = pyautogui.screenshot(region=(517, 720, 150, 50))  # x, y, width, height
screenshot_path = 'C:\\Users\\DELL\\PycharmProjects\\AUTO\\resource\\screenshot.png'
screenshot.save(screenshot_path)

# 读取图像并转换为灰度
image = cv2.imread(screenshot_path)
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# 自适应直方图均衡化
clahe = cv2.createCLAHE(clipLimit=20, tileGridSize=(12, 12))
gray_image = clahe.apply(gray_image)

# 颜色取反
enhanced_image = cv2.bitwise_not(gray_image)
# 显示增强后的图像
cv2.imshow("Enhanced Image", enhanced_image)
cv2.waitKey(0)

# 使用 pytesseract 识别数字
text = pytesseract.image_to_string(enhanced_image, config='--oem 3 --psm 6')
numbers = re.findall(r'\b\d+\b', text)
print(numbers)
list1 = numbers[0]

print(list1)
#
# screenshot2 = pyautogui.screenshot(region=(620, 722, 89, 47))  # x, y, width, height
# screenshot_path2 = 'C:\\Users\\DELL\\PycharmProjects\\AUTO\\resource\\screenshot2.png'
# screenshot2.save(screenshot_path2)
# image2 =cv2.imread(screenshot_path2)
# gray_image2 = cv2.cvtColor(image2, cv2.COLOR_BGR2GRAY)
# cv2.imshow("gray_image",gray_image2)
# cv2.waitKey(0)
# text2 = pytesseract.image_to_string(gray_image2, config='--oem 3 --psm 6')# 注意：'--oem 3' 表示使用LSTM OCR引擎，'--psm 6' 表示假设图像是一个单一的统一块文本。
# numbers2 = re.findall(r'\b\d+\b', text2)
# print(numbers2)
# ## 打印提取的数字
# screenshot3 = pyautogui.screenshot(region=(636, 730, 76, 30))  # x, y, width, height
# screenshot_path3 = 'C:\\Users\\DELL\\PycharmProjects\\AUTO\\resource\\screenshot3.png'
# screenshot3.save(screenshot_path3)
# image3 =cv2.imread(screenshot_path3)
# gray_image3 = cv2.cvtColor(image3, cv2.COLOR_BGR2GRAY)
# cv2.imshow("gray_image",gray_image3)
# cv2.waitKey(0)
# text3 = pytesseract.image_to_string(gray_image3, config='--oem 3 --psm 6')# 注意：'--oem 3' 表示使用LSTM OCR引擎，'--psm 6' 表示假设图像是一个单一的统一块文本。
# numbers3 = re.findall(r'\b\d+\b', text3)
# print(numbers2)
# int_num3=int(numbers3[0])
# int_num1=int(numbers[0])
# int_NUM=int(numbers2[0])
# target_finds =int( int_num1/40)
#
# The_target_finds =  target_finds +int_NUM-1
# print(f"共有 {int_num3 }额外开括力")
# print(f"共有 {int_num1 }开括力")
# print(f"共有 {int_NUM }沉浸器")
#
# print("有{:d}次".format(target_finds))#转化后的沉浸器
# print( The_target_finds) #点击次数
